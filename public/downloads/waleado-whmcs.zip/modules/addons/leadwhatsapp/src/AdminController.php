<?php

namespace LeadWhatsApp;

use WHMCS\Database\Capsule;

class AdminController
{
    /**
     * Handle incoming admin requests and render appropriate view
     */
    public static function handle(array $vars): string
    {
        $tab = $_GET['tab'] ?? 'dashboard';
        $action = $_POST['action'] ?? $_GET['action'] ?? '';
        $flashMessage = null;
        $flashType = 'success';

        // Process POST actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            switch ($action) {
                case 'save_credentials':
                    $apiUrl = trim($_POST['api_url'] ?? '');
                    $clientId = trim($_POST['client_id'] ?? '');
                    $clientSecret = trim($_POST['client_secret'] ?? '');
                    $adminPhone = trim($_POST['admin_phone'] ?? '');
                    $defaultCountryCode = preg_replace('/[^\d]/', '', $_POST['default_country_code'] ?? '880');
                    $verifyWhatsApp = !empty($_POST['verify_whatsapp_number']) ? 'on' : '';
                    $attachInvoicePdf = !empty($_POST['attach_invoice_pdf']) ? 'on' : 'off';
                    $customPhoneField = trim($_POST['custom_phone_field'] ?? '');
                    $debugLog = !empty($_POST['debug_log']) ? 'on' : '';

                    $settingsToSave = [
                        'api_url' => !empty($apiUrl) ? rtrim($apiUrl, '/') : 'http://localhost:3000',
                        'client_id' => $clientId,
                        'admin_phone' => $adminPhone,
                        'default_country_code' => !empty($defaultCountryCode) ? $defaultCountryCode : '880',
                        'attach_invoice_pdf' => $attachInvoicePdf,
                        'verify_whatsapp_number' => $verifyWhatsApp,
                        'custom_phone_field' => $customPhoneField,
                        'debug_log' => $debugLog,
                    ];

                    if (!empty($clientSecret)) {
                        $settingsToSave['client_secret'] = $clientSecret;
                    }

                    Database::saveModuleConfig($settingsToSave);

                    if (!empty($_POST['test_connection_after'])) {
                        $apiClient = ApiClient::fromConfig();
                        $apiTestResult = $apiClient->testConnection();
                        if ($apiTestResult['success']) {
                            $flashMessage = 'Credentials saved & API connection verified successfully!';
                            $flashType = 'success';
                        } else {
                            $flashMessage = 'Credentials saved, but API connection failed: ' . ($apiTestResult['message'] ?? 'Unknown error');
                            $flashType = 'warning';
                        }
                    } else {
                        $flashMessage = 'API Credentials and configuration updated successfully!';
                    }
                    $tab = 'dashboard';
                    break;

                case 'save_template':
                    $templateId = (int)($_POST['template_id'] ?? 0);
                    $templateText = trim($_POST['template_text'] ?? '');
                    $isActive = !empty($_POST['is_active']) ? 1 : 0;
                    $sendToAdmin = !empty($_POST['send_to_admin']) ? 1 : 0;

                    if ($templateId > 0 && !empty($templateText)) {
                        Database::updateTemplate($templateId, [
                            'template_text' => $templateText,
                            'is_active' => $isActive,
                            'send_to_admin' => $sendToAdmin,
                        ]);
                        $flashMessage = 'Notification template updated successfully!';
                    } else {
                        $flashMessage = 'Template text cannot be empty.';
                        $flashType = 'danger';
                    }
                    $tab = 'templates';
                    break;

                case 'toggle_template':
                    $templateId = (int)($_POST['template_id'] ?? $_GET['template_id'] ?? 0);
                    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') || isset($_POST['ajax']) || isset($_GET['ajax']);

                    if ($templateId > 0) {
                        $tpl = Capsule::table('mod_leadwhatsapp_templates')->where('id', $templateId)->first();
                        if ($tpl) {
                            $newStatus = isset($_POST['is_active']) ? ((int)$_POST['is_active'] ? 1 : 0) : ($tpl->is_active ? 0 : 1);
                            Database::updateTemplate($templateId, ['is_active' => $newStatus]);

                            if ($isAjax) {
                                if (!headers_sent()) {
                                    header('Content-Type: application/json');
                                }
                                echo json_encode([
                                    'success' => true,
                                    'template_id' => $templateId,
                                    'is_active' => $newStatus,
                                    'message' => $newStatus ? "Template '{$tpl->name}' enabled." : "Template '{$tpl->name}' disabled.",
                                ]);
                                exit;
                            }
                            $flashMessage = $newStatus ? "Template '{$tpl->name}' enabled successfully." : "Template '{$tpl->name}' disabled successfully.";
                        } else {
                            if ($isAjax) {
                                if (!headers_sent()) {
                                    header('Content-Type: application/json');
                                }
                                echo json_encode(['success' => false, 'message' => 'Template not found.']);
                                exit;
                            }
                            $flashMessage = 'Template not found.';
                            $flashType = 'danger';
                        }
                    }
                    $tab = 'templates';
                    break;

                case 'validate_phone':
                    $phone = trim($_POST['phone'] ?? $_GET['phone'] ?? '');
                    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') || isset($_POST['ajax']) || isset($_GET['ajax']);

                    $apiClient = ApiClient::fromConfig();
                    $result = $apiClient->validatePhone($phone);

                    if ($isAjax) {
                        if (!headers_sent()) {
                            header('Content-Type: application/json');
                        }
                        echo json_encode($result);
                        exit;
                    }

                    if ($result['success']) {
                        $flashMessage = "Phone '{$phone}' is a valid WhatsApp number!";
                    } else {
                        $flashMessage = 'Validation failed: ' . ($result['message'] ?? 'Not a valid WhatsApp number.');
                        $flashType = 'danger';
                    }
                    $tab = 'send_test';
                    break;

                case 'reset_templates':
                    Database::seedDefaultTemplates();
                    $flashMessage = 'Default templates have been reset/seeded!';
                    $tab = 'templates';
                    break;

                case 'send_direct':
                    $phone = trim($_POST['recipient_phone'] ?? '');
                    $message = trim($_POST['message_text'] ?? '');
                    $clientId = !empty($_POST['client_id']) ? (int)$_POST['client_id'] : null;
                    $attachInvoiceId = !empty($_POST['attach_invoice_id']) ? (int)$_POST['attach_invoice_id'] : 0;
                    $attachmentUrl = trim($_POST['attachment_url'] ?? '');

                    $attachment = null;
                    if ($attachInvoiceId > 0) {
                        $attachment = TemplateService::generateInvoicePdfAttachment($attachInvoiceId);
                    } elseif (!empty($attachmentUrl)) {
                        $attachment = [
                            'fileUrl' => $attachmentUrl,
                            'fileName' => trim($_POST['attachment_name'] ?? 'document.pdf'),
                            'mimeType' => 'application/pdf',
                        ];
                    }

                    if (empty($phone) || (empty($message) && empty($attachment))) {
                        $flashMessage = 'Please provide a valid phone number and message body or file attachment.';
                        $flashType = 'danger';
                    } else {
                        $result = TemplateService::sendDirect($phone, $message, $clientId, 'manual', $attachInvoiceId ?: null, $attachment);
                        if ($result['success']) {
                            $flashMessage = 'WhatsApp message dispatched successfully!';
                        } else {
                            $flashMessage = 'Failed to send message: ' . ($result['message'] ?? 'Unknown error');
                            $flashType = 'danger';
                        }
                    }
                    $tab = 'send_test';
                    break;

                case 'resend_log':
                    $logId = (int)($_POST['log_id'] ?? 0);
                    $log = Capsule::table('mod_leadwhatsapp_logs')->where('id', $logId)->first();
                    if ($log) {
                        $result = TemplateService::sendDirect($log->recipient_phone, $log->message_text, $log->client_id, $log->rel_type, $log->rel_id);
                        if ($result['success']) {
                            $flashMessage = 'Message resent successfully!';
                        } else {
                            $flashMessage = 'Resend failed: ' . ($result['message'] ?? 'Error');
                            $flashType = 'danger';
                        }
                    }
                    $tab = 'logs';
                    break;
            }
        }

        // Test Connection Action via GET
        $apiTestResult = null;
        if ($action === 'test_connection') {
            $apiClient = ApiClient::fromConfig();
            $apiTestResult = $apiClient->testConnection();
            if ($apiTestResult['success']) {
                $flashMessage = 'LeadWhatsApp API Connection Verified! Default device is ready.';
            } else {
                $flashMessage = 'Connection Test Failed: ' . ($apiTestResult['message'] ?? 'Unknown error');
                $flashType = 'danger';
            }
            $tab = 'dashboard';
        }

        // Prepare View Data
        $stats = Database::getStatistics();
        $templates = Database::getAllTemplates();
        $moduleConfig = Database::getModuleConfig();
        $moduleLink = $vars['modulelink'] ?? 'addonmodules.php?module=leadwhatsapp';

        // Render layout & tab
        ob_start();
        include dirname(__DIR__) . '/templates/admin/layout.php';
        return ob_get_clean();
    }
}
