<?php

namespace LeadWhatsApp\Hooks;

use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

class DomainHooks
{
    /**
     * Hook: AfterRegistrarRegistration
     */
    public static function onDomainRegistered(array $vars): void
    {
        $domainId = (int)($vars['params']['domainid'] ?? $vars['domainid'] ?? 0);
        if (!$domainId) {
            return;
        }

        $domain = Capsule::table('tbldomains')->where('id', $domainId)->first();
        if (!$domain) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $domain->userid)->first();
        if (!$client) {
            return;
        }

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'domain' => $domain->domain,
            'registration_period' => $domain->registrationperiod ?? 1,
            'expiry_date' => $domain->expirydate,
        ];

        TemplateService::dispatch('domain_registered', $variables, null, $domain->userid, 'domain', $domainId);
    }

    /**
     * Hook: AfterRegistrarRenewal
     */
    public static function onDomainRenewed(array $vars): void
    {
        $domainId = (int)($vars['params']['domainid'] ?? $vars['domainid'] ?? 0);
        if (!$domainId) {
            return;
        }

        $domain = Capsule::table('tbldomains')->where('id', $domainId)->first();
        if (!$domain) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $domain->userid)->first();
        if (!$client) {
            return;
        }

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'domain' => $domain->domain,
            'expiry_date' => $domain->expirydate,
        ];

        TemplateService::dispatch('domain_renewed', $variables, null, $domain->userid, 'domain', $domainId);
    }

    /**
     * Hook: DomainRenewalNotice
     */
    public static function onDomainRenewalNotice(array $vars): void
    {
        $domainId = (int)($vars['domainid'] ?? 0);
        if (!$domainId) {
            return;
        }

        $domain = Capsule::table('tbldomains')->where('id', $domainId)->first();
        if (!$domain) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $domain->userid)->first();
        if (!$client) {
            return;
        }

        $days = (int)(($vars['daysuntilexpiry'] ?? 30));

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'domain' => $domain->domain,
            'expiry_date' => $domain->expirydate,
            'days_until_expiry' => $days,
        ];

        TemplateService::dispatch('domain_renewal_notice', $variables, null, $domain->userid, 'domain', $domainId);
    }
}
