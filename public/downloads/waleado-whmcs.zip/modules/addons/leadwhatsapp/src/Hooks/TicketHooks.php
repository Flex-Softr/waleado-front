<?php

namespace LeadWhatsApp\Hooks;

use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

class TicketHooks
{
    /**
     * Hook: TicketOpen
     */
    public static function onTicketOpen(array $vars): void
    {
        $ticketId = (int)($vars['ticketid'] ?? 0);
        $clientId = (int)($vars['userid'] ?? 0);
        $subject = $vars['subject'] ?? '';
        $deptName = $vars['deptname'] ?? 'General';
        $priority = $vars['priority'] ?? 'Medium';

        if (!$ticketId) {
            return;
        }

        $ticket = Capsule::table('tbltickets')->where('id', $ticketId)->first();
        $ticketMask = $ticket->tid ?? $ticketId;
        $clientName = $vars['name'] ?? 'Client';

        if ($clientId > 0) {
            $client = Capsule::table('tblclients')->where('id', $clientId)->first();
            if ($client) {
                $clientName = trim($client->firstname . ' ' . $client->lastname);
            }
        }

        $ticketUrl = rtrim(TemplateService::getSystemUrl(), '/') . '/viewticket.php?tid=' . $ticketMask . '&c=' . ($ticket->c ?? '');

        $variables = [
            'client_name' => $clientName,
            'ticket_id' => $ticketId,
            'ticket_mask' => $ticketMask,
            'ticket_subject' => $subject,
            'ticket_dept' => $deptName,
            'ticket_priority' => $priority,
            'ticket_url' => $ticketUrl,
        ];

        // 1. Send confirmation to client
        if ($clientId > 0) {
            TemplateService::dispatch('ticket_opened_client', $variables, null, $clientId, 'ticket', $ticketId);
        }

        // 2. Send notification to admin
        TemplateService::dispatch('ticket_opened_admin', $variables, null, null, 'ticket', $ticketId);
    }

    /**
     * Hook: TicketAdminReply
     */
    public static function onTicketAdminReply(array $vars): void
    {
        $ticketId = (int)($vars['ticketid'] ?? 0);
        $replyId = (int)($vars['replyid'] ?? 0);
        $adminName = $vars['admin'] ?? 'Support Team';
        $message = strip_tags($vars['message'] ?? '');

        if (!$ticketId) {
            return;
        }

        $ticket = Capsule::table('tbltickets')->where('id', $ticketId)->first();
        if (!$ticket || !$ticket->userid) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $ticket->userid)->first();
        if (!$client) {
            return;
        }

        $snippet = mb_strlen($message) > 100 ? mb_substr($message, 0, 97) . '...' : $message;
        $ticketUrl = rtrim(TemplateService::getSystemUrl(), '/') . '/viewticket.php?tid=' . $ticket->tid . '&c=' . $ticket->c;

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'ticket_id' => $ticketId,
            'ticket_mask' => $ticket->tid,
            'ticket_subject' => $ticket->title,
            'staff_name' => $adminName,
            'reply_snippet' => $snippet,
            'ticket_url' => $ticketUrl,
        ];

        TemplateService::dispatch('ticket_admin_reply', $variables, null, $ticket->userid, 'ticket', $ticketId);
    }

    /**
     * Hook: TicketUserReply
     */
    public static function onTicketUserReply(array $vars): void
    {
        $ticketId = (int)($vars['ticketid'] ?? 0);
        if (!$ticketId) {
            return;
        }

        $ticket = Capsule::table('tbltickets')->where('id', $ticketId)->first();
        if (!$ticket) {
            return;
        }

        $clientName = $ticket->name ?? 'Client';
        if ($ticket->userid > 0) {
            $client = Capsule::table('tblclients')->where('id', $ticket->userid)->first();
            if ($client) {
                $clientName = trim($client->firstname . ' ' . $client->lastname);
            }
        }

        $variables = [
            'client_name' => $clientName,
            'ticket_id' => $ticketId,
            'ticket_mask' => $ticket->tid,
            'ticket_subject' => $ticket->title,
        ];

        TemplateService::dispatch('ticket_client_reply_admin', $variables, null, null, 'ticket', $ticketId);
    }

    /**
     * Hook: TicketClose
     */
    public static function onTicketClose(array $vars): void
    {
        $ticketId = (int)($vars['ticketid'] ?? 0);
        if (!$ticketId) {
            return;
        }

        $ticket = Capsule::table('tbltickets')->where('id', $ticketId)->first();
        if (!$ticket || !$ticket->userid) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $ticket->userid)->first();
        if (!$client) {
            return;
        }

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'ticket_id' => $ticketId,
            'ticket_mask' => $ticket->tid,
            'ticket_subject' => $ticket->title,
        ];

        TemplateService::dispatch('ticket_closed', $variables, null, $ticket->userid, 'ticket', $ticketId);
    }
}
