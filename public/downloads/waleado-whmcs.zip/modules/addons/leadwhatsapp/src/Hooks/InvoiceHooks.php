<?php

namespace LeadWhatsApp\Hooks;

use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

class InvoiceHooks
{
    /**
     * Cache processed invoice event keys to prevent duplicate dispatches in a single request lifecycle
     */
    private static array $processedEvents = [];

    /**
     * Hook: InvoiceCreated
     */
    public static function onInvoiceCreated(array $vars): void
    {
        $invoiceId = (int)($vars['invoiceid'] ?? 0);
        if (!$invoiceId || isset(self::$processedEvents['created_' . $invoiceId])) {
            return;
        }
        self::$processedEvents['created_' . $invoiceId] = true;

        $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$invoice) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $invoice->userid)->first();
        if (!$client) {
            return;
        }

        $currency = self::getClientCurrency($invoice->userid);
        $totalFormatted = self::formatAmount($invoice->total, $currency);
        $invoiceUrl = rtrim(TemplateService::getSystemUrl(), '/') . '/viewinvoice.php?id=' . $invoiceId;

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'invoice_id' => $invoiceId,
            'invoice_total' => $totalFormatted,
            'due_date' => $invoice->duedate,
            'invoice_url' => $invoiceUrl,
        ];

        TemplateService::dispatch('invoice_created', $variables, null, $invoice->userid, 'invoice', $invoiceId);
    }

    /**
     * Hook: InvoicePaid
     */
    public static function onInvoicePaid(array $vars): void
    {
        $invoiceId = (int)($vars['invoiceid'] ?? 0);
        if (!$invoiceId || isset(self::$processedEvents['paid_' . $invoiceId])) {
            return;
        }
        self::$processedEvents['paid_' . $invoiceId] = true;

        $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$invoice) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $invoice->userid)->first();
        if (!$client) {
            return;
        }

        // Fetch latest transaction for this invoice
        $transaction = Capsule::table('tblaccounts')
            ->where('invoiceid', $invoiceId)
            ->orderBy('id', 'desc')
            ->first();

        $currency = self::getClientCurrency($invoice->userid);
        $amountPaid = $transaction ? self::formatAmount($transaction->amountin, $currency) : self::formatAmount($invoice->total, $currency);
        $transId = $transaction->transid ?? 'N/A';
        $paymentMethod = $invoice->paymentmethod ?? 'Online';

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'invoice_id' => $invoiceId,
            'amount_paid' => $amountPaid,
            'trans_id' => $transId,
            'payment_method' => $paymentMethod,
            'invoice_url' => rtrim(TemplateService::getSystemUrl(), '/') . '/viewinvoice.php?id=' . $invoiceId,
        ];

        TemplateService::dispatch('invoice_paid', $variables, null, $invoice->userid, 'invoice', $invoiceId);
    }

    /**
     * Hook: InvoicePaymentReminder
     */
    public static function onInvoicePaymentReminder(array $vars): void
    {
        $invoiceId = (int)($vars['invoiceid'] ?? 0);
        $type = strtolower($vars['type'] ?? 'reminder'); // first, second, third, overdue, reminder

        if (!$invoiceId || isset(self::$processedEvents['reminder_' . $type . '_' . $invoiceId])) {
            return;
        }
        self::$processedEvents['reminder_' . $type . '_' . $invoiceId] = true;

        $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$invoice || $invoice->status !== 'Unpaid') {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $invoice->userid)->first();
        if (!$client) {
            return;
        }

        $currency = self::getClientCurrency($invoice->userid);
        $totalFormatted = self::formatAmount($invoice->total, $currency);
        $invoiceUrl = rtrim(TemplateService::getSystemUrl(), '/') . '/viewinvoice.php?id=' . $invoiceId;

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'invoice_id' => $invoiceId,
            'invoice_total' => $totalFormatted,
            'due_date' => $invoice->duedate,
            'invoice_url' => $invoiceUrl,
        ];

        $eventKey = 'invoice_payment_reminder_first';
        if (strpos($type, 'second') !== false) {
            $eventKey = 'invoice_payment_reminder_second';
        } elseif (strpos($type, 'third') !== false || strpos($type, 'overdue') !== false) {
            $eventKey = 'invoice_payment_reminder_third';
        }

        TemplateService::dispatch($eventKey, $variables, null, $invoice->userid, 'invoice', $invoiceId);
    }

    /**
     * Hook: InvoiceRefunded
     */
    public static function onInvoiceRefunded(array $vars): void
    {
        $invoiceId = (int)($vars['invoiceid'] ?? 0);
        if (!$invoiceId || isset(self::$processedEvents['refunded_' . $invoiceId])) {
            return;
        }
        self::$processedEvents['refunded_' . $invoiceId] = true;

        $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$invoice) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $invoice->userid)->first();
        if (!$client) {
            return;
        }

        $currency = self::getClientCurrency($invoice->userid);
        $refundAmount = self::formatAmount($vars['amount'] ?? $invoice->total, $currency);

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'invoice_id' => $invoiceId,
            'refund_amount' => $refundAmount,
        ];

        TemplateService::dispatch('invoice_refunded', $variables, null, $invoice->userid, 'invoice', $invoiceId);
    }

    /**
     * Hook: InvoiceCancelled
     */
    public static function onInvoiceCancelled(array $vars): void
    {
        $invoiceId = (int)($vars['invoiceid'] ?? 0);
        if (!$invoiceId || isset(self::$processedEvents['cancelled_' . $invoiceId])) {
            return;
        }
        self::$processedEvents['cancelled_' . $invoiceId] = true;

        $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
        if (!$invoice) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $invoice->userid)->first();
        if (!$client) {
            return;
        }

        $currency = self::getClientCurrency($invoice->userid);
        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'invoice_id' => $invoiceId,
            'invoice_total' => self::formatAmount($invoice->total, $currency),
        ];

        TemplateService::dispatch('invoice_cancelled', $variables, null, $invoice->userid, 'invoice', $invoiceId);
    }

    /**
     * Get client's currency object or default
     */
    private static function getClientCurrency(int $clientId): ?object
    {
        try {
            $client = Capsule::table('tblclients')->where('id', $clientId)->first();
            $currencyId = $client->currency ?? 1;
            return Capsule::table('tblcurrencies')->where('id', $currencyId)->first();
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Format currency amount with prefix/suffix
     */
    private static function formatAmount($amount, ?object $currency): string
    {
        $formatted = number_format((float)$amount, 2);
        if (!$currency) {
            return '$' . $formatted;
        }
        return ($currency->prefix ?? '$') . $formatted . ($currency->suffix ?? '');
    }
}
