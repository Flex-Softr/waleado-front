<?php

namespace LeadWhatsApp\Hooks;

use WHMCS\Database\Capsule;

class CronHooks
{
    /**
     * Hook: DailyCronJob
     */
    public static function onDailyCronJob(array $vars): void
    {
        try {
            // 1. Purge expired OTPs older than 24 hours
            Capsule::table('mod_leadwhatsapp_otp')
                ->where('created_at', '<', date('Y-m-d H:i:s', strtotime('-1 day')))
                ->delete();

            // 2. Cleanup message logs older than 90 days
            Capsule::table('mod_leadwhatsapp_logs')
                ->where('created_at', '<', date('Y-m-d H:i:s', strtotime('-90 days')))
                ->delete();

            if (function_exists('logActivity')) {
                logActivity('[LeadWhatsApp] Daily cron maintenance completed successfully.');
            }
        } catch (\Throwable $e) {
            // Ignore cron errors
        }
    }
}
