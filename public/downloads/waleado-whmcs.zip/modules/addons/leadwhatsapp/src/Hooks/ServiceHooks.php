<?php

namespace LeadWhatsApp\Hooks;

use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

class ServiceHooks
{
    private static array $processedEvents = [];

    /**
     * Hook: AcceptOrder
     */
    public static function onAcceptOrder(array $vars): void
    {
        $orderId = (int)($vars['orderid'] ?? 0);
        if (!$orderId || isset(self::$processedEvents['order_accepted_' . $orderId])) {
            return;
        }
        self::$processedEvents['order_accepted_' . $orderId] = true;

        $order = Capsule::table('tblorders')->where('id', $orderId)->first();
        if (!$order) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $order->userid)->first();
        if (!$client) {
            return;
        }

        // Get first product name from hosting services in this order
        $service = Capsule::table('tblhosting')
            ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
            ->where('tblhosting.orderid', $orderId)
            ->select('tblproducts.name as product_name', 'tblhosting.domain')
            ->first();

        $productName = $service->product_name ?? 'Service Package';
        $domain = $service->domain ?? '';

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'order_id' => $orderId,
            'order_number' => $order->ordernumber ?? $orderId,
            'product_name' => $productName,
            'domain' => $domain,
        ];

        TemplateService::dispatch('service_order_accepted', $variables, null, $order->userid, 'order', $orderId);
    }

    /**
     * Hook: AfterModuleCreate
     */
    public static function onAfterModuleCreate(array $vars): void
    {
        $serviceId = (int)($vars['params']['serviceid'] ?? $vars['serviceid'] ?? 0);
        if (!$serviceId) {
            return;
        }

        $service = Capsule::table('tblhosting')
            ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
            ->join('tblclients', 'tblclients.id', '=', 'tblhosting.userid')
            ->where('tblhosting.id', $serviceId)
            ->select(
                'tblhosting.*',
                'tblproducts.name as product_name',
                'tblclients.firstname',
                'tblclients.lastname'
            )
            ->first();

        if (!$service) {
            return;
        }

        $server = null;
        if (!empty($service->server)) {
            $server = Capsule::table('tblservers')->where('id', $service->server)->first();
        }

        $variables = [
            'client_name' => trim($service->firstname . ' ' . $service->lastname),
            'product_name' => $service->product_name,
            'domain' => $service->domain ?? 'N/A',
            'username' => $service->username ?? 'N/A',
            'server_ip' => $server->ipaddress ?? 'N/A',
            'server_hostname' => $server->hostname ?? 'N/A',
        ];

        TemplateService::dispatch('service_created', $variables, null, $service->userid, 'service', $serviceId);
    }

    /**
     * Hook: AfterModuleSuspend
     */
    public static function onAfterModuleSuspend(array $vars): void
    {
        $serviceId = (int)($vars['params']['serviceid'] ?? $vars['serviceid'] ?? 0);
        if (!$serviceId) {
            return;
        }

        $service = Capsule::table('tblhosting')
            ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
            ->join('tblclients', 'tblclients.id', '=', 'tblhosting.userid')
            ->where('tblhosting.id', $serviceId)
            ->select(
                'tblhosting.*',
                'tblproducts.name as product_name',
                'tblclients.firstname',
                'tblclients.lastname'
            )
            ->first();

        if (!$service) {
            return;
        }

        $variables = [
            'client_name' => trim($service->firstname . ' ' . $service->lastname),
            'product_name' => $service->product_name,
            'domain' => $service->domain ?? 'N/A',
            'suspend_reason' => $service->suspendreason ?: 'Overdue Invoice or Policy Violation',
            'invoice_url' => rtrim(TemplateService::getSystemUrl(), '/') . '/clientarea.php?action=invoices',
        ];

        TemplateService::dispatch('service_suspended', $variables, null, $service->userid, 'service', $serviceId);
    }

    /**
     * Hook: AfterModuleUnsuspend
     */
    public static function onAfterModuleUnsuspend(array $vars): void
    {
        $serviceId = (int)($vars['params']['serviceid'] ?? $vars['serviceid'] ?? 0);
        if (!$serviceId) {
            return;
        }

        $service = Capsule::table('tblhosting')
            ->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')
            ->join('tblclients', 'tblclients.id', '=', 'tblhosting.userid')
            ->where('tblhosting.id', $serviceId)
            ->select(
                'tblhosting.*',
                'tblproducts.name as product_name',
                'tblclients.firstname',
                'tblclients.lastname'
            )
            ->first();

        if (!$service) {
            return;
        }

        $variables = [
            'client_name' => trim($service->firstname . ' ' . $service->lastname),
            'product_name' => $service->product_name,
            'domain' => $service->domain ?? 'N/A',
        ];

        TemplateService::dispatch('service_unsuspended', $variables, null, $service->userid, 'service', $serviceId);
    }
}
