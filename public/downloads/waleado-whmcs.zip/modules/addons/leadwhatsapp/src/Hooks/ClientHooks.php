<?php

namespace LeadWhatsApp\Hooks;

use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

class ClientHooks
{
    /**
     * Hook: ClientAdd
     */
    public static function onClientAdd(array $vars): void
    {
        $clientId = (int)($vars['client_id'] ?? $vars['userid'] ?? 0);
        if (!$clientId) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return;
        }

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'client_firstname' => $client->firstname,
            'client_lastname' => $client->lastname,
            'client_email' => $client->email,
            'client_id' => $clientId,
        ];

        // 1. Welcome to client
        TemplateService::dispatch('client_registered', $variables, null, $clientId, 'client', $clientId);

        // 2. Alert to admin
        TemplateService::dispatch('client_registered_admin', $variables, null, null, 'client', $clientId);
    }

    /**
     * Hook: ClientLogin
     */
    public static function onClientLogin(array $vars): void
    {
        $clientId = (int)($vars['userid'] ?? 0);
        if (!$clientId) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return;
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'ip_address' => $ip,
            'login_time' => date('Y-m-d H:i:s'),
        ];

        TemplateService::dispatch('client_login_alert', $variables, null, $clientId, 'client', $clientId);
    }

    /**
     * Hook: AdminLogin
     */
    public static function onAdminLogin(array $vars): void
    {
        $adminUsername = $vars['username'] ?? 'Admin';
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';

        $variables = [
            'admin_username' => $adminUsername,
            'ip_address' => $ip,
            'login_time' => date('Y-m-d H:i:s'),
        ];

        TemplateService::dispatch('admin_login_alert', $variables, null, null, 'admin', null);
    }

    /**
     * Hook: ClientChangePassword
     */
    public static function onClientChangePassword(array $vars): void
    {
        $clientId = (int)($vars['userid'] ?? 0);
        if (!$clientId) {
            return;
        }

        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return;
        }

        $variables = [
            'client_name' => trim($client->firstname . ' ' . $client->lastname),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP',
            'change_time' => date('Y-m-d H:i:s'),
        ];

        TemplateService::dispatch('client_password_changed', $variables, null, $clientId, 'client', $clientId);
    }
}
