<?php

namespace LeadWhatsApp;

use WHMCS\Database\Capsule;

/**
 * Phone Number Normalization and Resolution Helper for WHMCS
 */
class PhoneHelper
{
    /**
     * Format raw phone number into clean international format (E.164 with +)
     */
    public static function normalize(string $rawPhone, ?string $defaultCountryPrefix = null): string
    {
        $rawPhone = trim($rawPhone);
        if (empty($rawPhone)) {
            return '';
        }

        // Get module default country code if not passed
        if ($defaultCountryPrefix === null) {
            $config = Database::getModuleConfig();
            $defaultCountryPrefix = preg_replace('/[^\d]/', '', $config['default_country_code'] ?? '880');
        } else {
            $defaultCountryPrefix = preg_replace('/[^\d]/', '', $defaultCountryPrefix);
        }
        if (empty($defaultCountryPrefix)) {
            $defaultCountryPrefix = '880';
        }

        // 1. Handle WHMCS standard phone format with dot separator: e.g. "880.01712345678", "880.1712345678", "1.4155552671"
        if (strpos($rawPhone, '.') !== false) {
            $parts = explode('.', $rawPhone, 2);
            $cc = preg_replace('/[^\d]/', '', $parts[0]);
            $num = preg_replace('/[^\d]/', '', $parts[1]);
            // Remove leading zero from national number if present (e.g. 017... -> 17...)
            $num = ltrim($num, '0');
            if (!empty($cc) && !empty($num)) {
                return '+' . $cc . $num;
            }
        }

        // 2. Remove all non-digit and non-plus characters
        $cleaned = preg_replace('/[^\d+]/', '', $rawPhone);
        if (empty($cleaned)) {
            return '';
        }

        // 3. Handle international prefixes: "00" prefix (e.g. 0088017...)
        if (strpos($cleaned, '00') === 0) {
            $cleaned = '+' . substr($cleaned, 2);
        }

        // 4. If starts with "+"
        if (strpos($cleaned, '+') === 0) {
            $digits = substr($cleaned, 1);
            // Check if user entered redundant 0 after country code (e.g. +880017...)
            if (!empty($defaultCountryPrefix) && strpos($digits, $defaultCountryPrefix . '0') === 0) {
                $digits = $defaultCountryPrefix . substr($digits, strlen($defaultCountryPrefix) + 1);
            }
            return '+' . ltrim($digits, '0');
        }

        // 5. If starts with 0 (national trunk prefix, e.g. 017xxxxxxxx)
        if (strpos($cleaned, '0') === 0 && !empty($defaultCountryPrefix)) {
            $national = ltrim($cleaned, '0');
            return '+' . $defaultCountryPrefix . $national;
        }

        // 6. If it starts with country code followed by 0 (e.g. 88001712345678)
        if (!empty($defaultCountryPrefix) && strpos($cleaned, $defaultCountryPrefix . '0') === 0) {
            $national = substr($cleaned, strlen($defaultCountryPrefix) + 1);
            return '+' . $defaultCountryPrefix . $national;
        }

        // 7. If it starts with the country code already (e.g. 88017...)
        if (!empty($defaultCountryPrefix) && strpos($cleaned, $defaultCountryPrefix) === 0) {
            return '+' . $cleaned;
        }

        // 8. Fallback: If 7-10 digits, prepend default country code
        if (strlen($cleaned) <= 10 && !empty($defaultCountryPrefix)) {
            return '+' . $defaultCountryPrefix . ltrim($cleaned, '0');
        }

        return '+' . $cleaned;
    }

    /**
     * Check if a phone number is a valid international E.164 formatted number
     * (e.g. +8801712345678, +14155552671, +447123456789)
     */
    public static function isValid(string $phone): bool
    {
        $cleaned = trim($phone);
        if (empty($cleaned)) {
            return false;
        }

        // Must start with + followed by non-zero digit and 6 to 14 more digits (7-15 total digits according to E.164)
        return (bool)preg_match('/^\+[1-9]\d{6,14}$/', $cleaned);
    }

    /**
     * Mask phone number for privacy display (e.g. +88017****5678)
     */
    public static function mask(string $phone): string
    {
        $phone = trim($phone);
        $len = strlen($phone);
        if ($len <= 6) {
            return $phone;
        }
        return substr($phone, 0, 6) . '****' . substr($phone, -3);
    }

    /**
     * Resolve a client's WhatsApp phone number from WHMCS database
     * Checks custom field first (if configured in module), then falls back to client profile phonenumber
     */
    public static function getClientPhone(int $clientId): ?string
    {
        if ($clientId <= 0) {
            return null;
        }

        try {
            $config = Database::getModuleConfig();
            $customFieldName = trim($config['custom_phone_field'] ?? '');

            // 1. Check Custom Field if defined
            if (!empty($customFieldName)) {
                $customVal = Capsule::table('tblcustomfieldsvalues')
                    ->join('tblcustomfields', 'tblcustomfields.id', '=', 'tblcustomfieldsvalues.fieldid')
                    ->where('tblcustomfields.relid', 0) // Client custom fields
                    ->where('tblcustomfields.type', 'client')
                    ->where('tblcustomfields.fieldname', 'like', '%' . $customFieldName . '%')
                    ->where('tblcustomfieldsvalues.relid', $clientId)
                    ->value('tblcustomfieldsvalues.value');

                if (!empty($customVal)) {
                    $normalized = self::normalize($customVal);
                    if (!empty($normalized) && self::isValid($normalized)) {
                        return $normalized;
                    }
                }
            }

            // 2. Fetch Client profile
            $client = Capsule::table('tblclients')->where('id', $clientId)->first();
            if (!$client) {
                return null;
            }

            $rawPhone = $client->phonenumber ?? '';
            $country = $client->country ?? '';
            $countryCode = self::getCountryDialCode($country);

            $normalized = self::normalize($rawPhone, $countryCode);
            return !empty($normalized) ? $normalized : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Map ISO-2 country code to international dialing prefix
     */
    public static function getCountryDialCode(string $countryIso2, ?string $default = null): string
    {
        $countryIso2 = strtoupper(trim($countryIso2));
        $codes = self::getIsoToDialCodeMap();

        if (isset($codes[$countryIso2])) {
            return $codes[$countryIso2];
        }

        if ($default !== null) {
            return preg_replace('/[^\d]/', '', $default);
        }

        try {
            $config = Database::getModuleConfig();
            return preg_replace('/[^\d]/', '', $config['default_country_code'] ?? '880') ?: '880';
        } catch (\Throwable $e) {
            return '880';
        }
    }

    /**
     * Get ISO-2 to Dial Code Map
     */
    public static function getIsoToDialCodeMap(): array
    {
        $map = [];
        foreach (self::getCountryList() as $c) {
            $map[$c['code']] = $c['dial_code'];
        }
        $map['UK'] = '44';
        return $map;
    }

    /**
     * Complete list of countries with dial codes, names, ISO codes, and flags
     */
    public static function getCountryList(): array
    {
        return [
            ['code' => 'BD', 'name' => 'Bangladesh', 'dial_code' => '880', 'flag' => '🇧🇩', 'popular' => true],
            ['code' => 'US', 'name' => 'United States', 'dial_code' => '1', 'flag' => '🇺🇸', 'popular' => true],
            ['code' => 'GB', 'name' => 'United Kingdom', 'dial_code' => '44', 'flag' => '🇬🇧', 'popular' => true],
            ['code' => 'AE', 'name' => 'United Arab Emirates', 'dial_code' => '971', 'flag' => '🇦🇪', 'popular' => true],
            ['code' => 'SA', 'name' => 'Saudi Arabia', 'dial_code' => '966', 'flag' => '🇸🇦', 'popular' => true],
            ['code' => 'IN', 'name' => 'India', 'dial_code' => '91', 'flag' => '🇮🇳', 'popular' => true],
            ['code' => 'PK', 'name' => 'Pakistan', 'dial_code' => '92', 'flag' => '🇵🇰', 'popular' => true],
            ['code' => 'CA', 'name' => 'Canada', 'dial_code' => '1', 'flag' => '🇨🇦', 'popular' => true],
            ['code' => 'AU', 'name' => 'Australia', 'dial_code' => '61', 'flag' => '🇦🇺', 'popular' => true],
            ['code' => 'DE', 'name' => 'Germany', 'dial_code' => '49', 'flag' => '🇩🇪', 'popular' => true],
            ['code' => 'SG', 'name' => 'Singapore', 'dial_code' => '65', 'flag' => '🇸🇬', 'popular' => true],
            ['code' => 'MY', 'name' => 'Malaysia', 'dial_code' => '60', 'flag' => '🇲🇾', 'popular' => true],
            ['code' => 'QA', 'name' => 'Qatar', 'dial_code' => '974', 'flag' => '🇶🇦', 'popular' => true],
            ['code' => 'KW', 'name' => 'Kuwait', 'dial_code' => '965', 'flag' => '🇰🇼', 'popular' => true],
            ['code' => 'OM', 'name' => 'Oman', 'dial_code' => '968', 'flag' => '🇴🇲', 'popular' => true],
            ['code' => 'BH', 'name' => 'Bahrain', 'dial_code' => '973', 'flag' => '🇧🇭', 'popular' => true],
            ['code' => 'FR', 'name' => 'France', 'dial_code' => '33', 'flag' => '🇫🇷', 'popular' => true],
            ['code' => 'IT', 'name' => 'Italy', 'dial_code' => '39', 'flag' => '🇮🇹', 'popular' => false],
            ['code' => 'ES', 'name' => 'Spain', 'dial_code' => '34', 'flag' => '🇪🇸', 'popular' => false],
            ['code' => 'NL', 'name' => 'Netherlands', 'dial_code' => '31', 'flag' => '🇳🇱', 'popular' => false],
            ['code' => 'TR', 'name' => 'Turkey', 'dial_code' => '90', 'flag' => '🇹🇷', 'popular' => true],
            ['code' => 'EG', 'name' => 'Egypt', 'dial_code' => '20', 'flag' => '🇪🇬', 'popular' => true],
            ['code' => 'ZA', 'name' => 'South Africa', 'dial_code' => '27', 'flag' => '🇿🇦', 'popular' => true],
            ['code' => 'NG', 'name' => 'Nigeria', 'dial_code' => '234', 'flag' => '🇳🇬', 'popular' => true],
            ['code' => 'KE', 'name' => 'Kenya', 'dial_code' => '254', 'flag' => '🇰🇪', 'popular' => false],
            ['code' => 'ID', 'name' => 'Indonesia', 'dial_code' => '62', 'flag' => '🇮🇩', 'popular' => false],
            ['code' => 'PH', 'name' => 'Philippines', 'dial_code' => '63', 'flag' => '🇵🇭', 'popular' => false],
            ['code' => 'TH', 'name' => 'Thailand', 'dial_code' => '66', 'flag' => '🇹🇭', 'popular' => false],
            ['code' => 'VN', 'name' => 'Vietnam', 'dial_code' => '84', 'flag' => '🇻🇳', 'popular' => false],
            ['code' => 'JP', 'name' => 'Japan', 'dial_code' => '81', 'flag' => '🇯🇵', 'popular' => false],
            ['code' => 'KR', 'name' => 'South Korea', 'dial_code' => '82', 'flag' => '🇰🇷', 'popular' => false],
            ['code' => 'CN', 'name' => 'China', 'dial_code' => '86', 'flag' => '🇨🇳', 'popular' => false],
            ['code' => 'HK', 'name' => 'Hong Kong', 'dial_code' => '852', 'flag' => '🇭🇰', 'popular' => false],
            ['code' => 'TW', 'name' => 'Taiwan', 'dial_code' => '886', 'flag' => '🇹🇼', 'popular' => false],
            ['code' => 'LK', 'name' => 'Sri Lanka', 'dial_code' => '94', 'flag' => '🇱🇰', 'popular' => false],
            ['code' => 'NP', 'name' => 'Nepal', 'dial_code' => '977', 'flag' => '🇳🇵', 'popular' => false],
            ['code' => 'MV', 'name' => 'Maldives', 'dial_code' => '960', 'flag' => '🇲🇻', 'popular' => false],
            ['code' => 'BT', 'name' => 'Bhutan', 'dial_code' => '975', 'flag' => '🇧🇹', 'popular' => false],
            ['code' => 'AF', 'name' => 'Afghanistan', 'dial_code' => '93', 'flag' => '🇦🇫', 'popular' => false],
            ['code' => 'AL', 'name' => 'Albania', 'dial_code' => '355', 'flag' => '🇦🇱', 'popular' => false],
            ['code' => 'DZ', 'name' => 'Algeria', 'dial_code' => '213', 'flag' => '🇩🇿', 'popular' => false],
            ['code' => 'AD', 'name' => 'Andorra', 'dial_code' => '376', 'flag' => '🇦🇩', 'popular' => false],
            ['code' => 'AO', 'name' => 'Angola', 'dial_code' => '244', 'flag' => '🇦🇴', 'popular' => false],
            ['code' => 'AR', 'name' => 'Argentina', 'dial_code' => '54', 'flag' => '🇦🇷', 'popular' => false],
            ['code' => 'AM', 'name' => 'Armenia', 'dial_code' => '374', 'flag' => '🇦🇲', 'popular' => false],
            ['code' => 'AT', 'name' => 'Austria', 'dial_code' => '43', 'flag' => '🇦🇹', 'popular' => false],
            ['code' => 'AZ', 'name' => 'Azerbaijan', 'dial_code' => '994', 'flag' => '🇦🇿', 'popular' => false],
            ['code' => 'BE', 'name' => 'Belgium', 'dial_code' => '32', 'flag' => '🇧🇪', 'popular' => false],
            ['code' => 'BR', 'name' => 'Brazil', 'dial_code' => '55', 'flag' => '🇧🇷', 'popular' => false],
            ['code' => 'BG', 'name' => 'Bulgaria', 'dial_code' => '359', 'flag' => '🇧🇬', 'popular' => false],
            ['code' => 'CL', 'name' => 'Chile', 'dial_code' => '56', 'flag' => '🇨🇱', 'popular' => false],
            ['code' => 'CO', 'name' => 'Colombia', 'dial_code' => '57', 'flag' => '🇨🇴', 'popular' => false],
            ['code' => 'CR', 'name' => 'Costa Rica', 'dial_code' => '506', 'flag' => '🇨🇷', 'popular' => false],
            ['code' => 'HR', 'name' => 'Croatia', 'dial_code' => '385', 'flag' => '🇭🇷', 'popular' => false],
            ['code' => 'CY', 'name' => 'Cyprus', 'dial_code' => '357', 'flag' => '🇨🇾', 'popular' => false],
            ['code' => 'CZ', 'name' => 'Czech Republic', 'dial_code' => '420', 'flag' => '🇨🇿', 'popular' => false],
            ['code' => 'DK', 'name' => 'Denmark', 'dial_code' => '45', 'flag' => '🇩🇰', 'popular' => false],
            ['code' => 'EC', 'name' => 'Ecuador', 'dial_code' => '593', 'flag' => '🇪🇨', 'popular' => false],
            ['code' => 'EE', 'name' => 'Estonia', 'dial_code' => '372', 'flag' => '🇪🇪', 'popular' => false],
            ['code' => 'ET', 'name' => 'Ethiopia', 'dial_code' => '251', 'flag' => '🇪🇹', 'popular' => false],
            ['code' => 'FI', 'name' => 'Finland', 'dial_code' => '358', 'flag' => '🇫🇮', 'popular' => false],
            ['code' => 'GE', 'name' => 'Georgia', 'dial_code' => '995', 'flag' => '🇬🇪', 'popular' => false],
            ['code' => 'GH', 'name' => 'Ghana', 'dial_code' => '233', 'flag' => '🇬🇭', 'popular' => false],
            ['code' => 'GR', 'name' => 'Greece', 'dial_code' => '30', 'flag' => '🇬🇷', 'popular' => false],
            ['code' => 'HU', 'name' => 'Hungary', 'dial_code' => '36', 'flag' => '🇭🇺', 'popular' => false],
            ['code' => 'IS', 'name' => 'Iceland', 'dial_code' => '354', 'flag' => '🇮🇸', 'popular' => false],
            ['code' => 'IQ', 'name' => 'Iraq', 'dial_code' => '964', 'flag' => '🇮🇶', 'popular' => false],
            ['code' => 'IE', 'name' => 'Ireland', 'dial_code' => '353', 'flag' => '🇮🇪', 'popular' => false],
            ['code' => 'IL', 'name' => 'Israel', 'dial_code' => '972', 'flag' => '🇮🇱', 'popular' => false],
            ['code' => 'JO', 'name' => 'Jordan', 'dial_code' => '962', 'flag' => '🇯🇴', 'popular' => false],
            ['code' => 'KZ', 'name' => 'Kazakhstan', 'dial_code' => '7', 'flag' => '🇰🇿', 'popular' => false],
            ['code' => 'LB', 'name' => 'Lebanon', 'dial_code' => '961', 'flag' => '🇱🇧', 'popular' => false],
            ['code' => 'LU', 'name' => 'Luxembourg', 'dial_code' => '352', 'flag' => '🇱🇺', 'popular' => false],
            ['code' => 'MA', 'name' => 'Morocco', 'dial_code' => '212', 'flag' => '🇲🇦', 'popular' => false],
            ['code' => 'MT', 'name' => 'Malta', 'dial_code' => '356', 'flag' => '🇲🇹', 'popular' => false],
            ['code' => 'MU', 'name' => 'Mauritius', 'dial_code' => '230', 'flag' => '🇲🇺', 'popular' => false],
            ['code' => 'MX', 'name' => 'Mexico', 'dial_code' => '52', 'flag' => '🇲🇽', 'popular' => false],
            ['code' => 'MD', 'name' => 'Moldova', 'dial_code' => '373', 'flag' => '🇲🇩', 'popular' => false],
            ['code' => 'NO', 'name' => 'Norway', 'dial_code' => '47', 'flag' => '🇳🇴', 'popular' => false],
            ['code' => 'NZ', 'name' => 'New Zealand', 'dial_code' => '64', 'flag' => '🇳🇿', 'popular' => false],
            ['code' => 'PE', 'name' => 'Peru', 'dial_code' => '51', 'flag' => '🇵🇪', 'popular' => false],
            ['code' => 'PL', 'name' => 'Poland', 'dial_code' => '48', 'flag' => '🇵🇱', 'popular' => false],
            ['code' => 'PT', 'name' => 'Portugal', 'dial_code' => '351', 'flag' => '🇵🇹', 'popular' => false],
            ['code' => 'RO', 'name' => 'Romania', 'dial_code' => '40', 'flag' => '🇷🇴', 'popular' => false],
            ['code' => 'RS', 'name' => 'Serbia', 'dial_code' => '381', 'flag' => '🇷🇸', 'popular' => false],
            ['code' => 'RU', 'name' => 'Russia', 'dial_code' => '7', 'flag' => '🇷🇺', 'popular' => false],
            ['code' => 'SK', 'name' => 'Slovakia', 'dial_code' => '421', 'flag' => '🇸🇰', 'popular' => false],
            ['code' => 'SI', 'name' => 'Slovenia', 'dial_code' => '386', 'flag' => '🇸🇮', 'popular' => false],
            ['code' => 'SE', 'name' => 'Sweden', 'dial_code' => '46', 'flag' => '🇸🇪', 'popular' => false],
            ['code' => 'CH', 'name' => 'Switzerland', 'dial_code' => '41', 'flag' => '🇨🇭', 'popular' => false],
            ['code' => 'TN', 'name' => 'Tunisia', 'dial_code' => '216', 'flag' => '🇹🇳', 'popular' => false],
            ['code' => 'UA', 'name' => 'Ukraine', 'dial_code' => '380', 'flag' => '🇺🇦', 'popular' => false],
            ['code' => 'UG', 'name' => 'Uganda', 'dial_code' => '256', 'flag' => '🇺🇬', 'popular' => false],
            ['code' => 'UZ', 'name' => 'Uzbekistan', 'dial_code' => '998', 'flag' => '🇺🇿', 'popular' => false],
            ['code' => 'VN', 'name' => 'Vietnam', 'dial_code' => '84', 'flag' => '🇻🇳', 'popular' => false],
            ['code' => 'ZW', 'name' => 'Zimbabwe', 'dial_code' => '263', 'flag' => '🇿🇼', 'popular' => false],
        ];
    }
}
