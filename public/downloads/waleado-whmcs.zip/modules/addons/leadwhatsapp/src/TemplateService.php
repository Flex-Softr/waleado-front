<?php

namespace LeadWhatsApp;

use WHMCS\Database\Capsule;

/**
 * Template Rendering and Notification Dispatch Service
 */
class TemplateService
{
    /**
     * Replace template merge tags with dynamic values
     */
    public static function parse(string $templateText, array $variables = []): string
    {
        // Global variables available in all templates
        $globalVars = [
            'company_name' => self::getCompanyName(),
            'system_url' => self::getSystemUrl(),
            'clientarea_url' => rtrim(self::getSystemUrl(), '/') . '/clientarea.php',
            'current_date' => date('Y-m-d'),
            'current_time' => date('H:i'),
        ];

        $merged = array_merge($globalVars, $variables);

        $keys = [];
        $values = [];
        foreach ($merged as $k => $v) {
            $keys[] = '{' . trim($k, '{}') . '}';
            $values[] = (string)($v ?? '');
        }

        return str_replace($keys, $values, $templateText);
    }

    /**
     * Generate or resolve invoice PDF attachment for an invoice ID
     */
    public static function generateInvoicePdfAttachment(int $invoiceId): ?array
    {
        if ($invoiceId <= 0) {
            return null;
        }

        try {
            $config = Database::getModuleConfig();
            // Check if PDF attachment is disabled in settings
            if (isset($config['attach_invoice_pdf']) && $config['attach_invoice_pdf'] === 'off') {
                return null;
            }

            // 1. Try WHMCS native pdfInvoice function
            if (!function_exists('pdfInvoice')) {
                if (defined('ROOTDIR') && file_exists(ROOTDIR . '/includes/invoicefunctions.php')) {
                    @include_once ROOTDIR . '/includes/invoicefunctions.php';
                }
            }

            $pdfBinary = null;
            if (function_exists('pdfInvoice')) {
                try {
                    $pdfBinary = pdfInvoice($invoiceId);
                } catch (\Throwable $ePdf) {
                    $pdfBinary = null;
                }
            }

            if (!empty($pdfBinary) && is_string($pdfBinary)) {
                return [
                    'fileData' => base64_encode($pdfBinary),
                    'fileName' => "Invoice-{$invoiceId}.pdf",
                    'mimeType' => 'application/pdf',
                ];
            }

            // 2. Fallback: Direct system URL to invoice PDF view or download
            $systemUrl = self::getSystemUrl();
            if (!empty($systemUrl)) {
                return [
                    'fileUrl' => rtrim($systemUrl, '/') . '/viewinvoice.php?id=' . $invoiceId,
                    'fileName' => "Invoice-{$invoiceId}.pdf",
                    'mimeType' => 'application/pdf',
                ];
            }

            return null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Dispatch an event-based WhatsApp notification
     */
    public static function dispatch(
        string $eventKey,
        array $variables,
        ?string $recipientPhone = null,
        ?int $clientId = null,
        ?string $relType = null,
        ?int $relId = null,
        ?array $attachment = null
    ): array {
        // 1. Fetch template
        $template = Database::getTemplate($eventKey);
        if (!$template || !$template->is_active) {
            return [
                'success' => false,
                'message' => "Template for event '{$eventKey}' is disabled or does not exist.",
                'skipped' => true,
            ];
        }

        $config = Database::getModuleConfig();

        // 2. Resolve recipient phone
        if ($template->send_to_admin) {
            $phone = trim($config['admin_phone'] ?? '');
            if (empty($phone)) {
                return [
                    'success' => false,
                    'message' => "Admin notification skipped: Admin phone number is not configured in module settings.",
                    'skipped' => true,
                ];
            }
            $phone = PhoneHelper::normalize($phone);
        } else {
            $phone = $recipientPhone;
            if (empty($phone) && $clientId) {
                $phone = PhoneHelper::getClientPhone($clientId);
            }
            if (!empty($phone)) {
                $phone = PhoneHelper::normalize($phone);
            }
        }

        if (empty($phone) || !PhoneHelper::isValid($phone)) {
            return [
                'success' => false,
                'message' => "Notification skipped: '" . ($phone ?: 'empty') . "' is not a valid international phone number.",
                'skipped' => true,
            ];
        }

        // 3. Render message body
        $messageBody = self::parse($template->template_text, $variables);

        // 4. Auto-attach Invoice PDF if event is invoice-related and no custom attachment was passed
        if ($attachment === null && ($relType === 'invoice' || strpos($eventKey, 'invoice_') === 0) && !empty($relId)) {
            $attachment = self::generateInvoicePdfAttachment((int)$relId);
        }

        // 5. Create log record (pending)
        $logId = Database::logMessage([
            'rel_type' => $relType,
            'rel_id' => $relId,
            'recipient_phone' => $phone,
            'client_id' => $clientId,
            'event_key' => $eventKey,
            'message_text' => $messageBody,
            'status' => 'pending',
        ]);

        // 6. Send message via LeadWhatsApp API (verifies WhatsApp number before sending)
        $apiClient = ApiClient::fromConfig();
        $response = $apiClient->sendMessage($phone, $messageBody, true, $attachment);

        // 7. Update log record
        if ($response['success']) {
            Database::updateLog($logId, 'sent', $response['data'] ?? null, null);
        } else {
            Database::updateLog($logId, 'failed', $response['data'] ?? null, $response['message'] ?? 'Send failed');
        }

        return $response;
    }

    /**
     * Send direct custom message (used for manual sending or test messages)
     */
    public static function sendDirect(
        string $phone,
        string $message,
        ?int $clientId = null,
        ?string $relType = 'custom',
        ?int $relId = null,
        ?array $attachment = null
    ): array {
        $normalizedPhone = PhoneHelper::normalize($phone);
        if (empty($normalizedPhone) || !PhoneHelper::isValid($normalizedPhone)) {
            return [
                'success' => false,
                'message' => "Invalid phone number '{$phone}'. A valid international number with country code is required (e.g. +88017XXXXXXXX).",
            ];
        }

        $logId = Database::logMessage([
            'rel_type' => $relType,
            'rel_id' => $relId,
            'recipient_phone' => $normalizedPhone,
            'client_id' => $clientId,
            'event_key' => 'custom_direct',
            'message_text' => $message,
            'status' => 'pending',
        ]);

        $apiClient = ApiClient::fromConfig();
        $response = $apiClient->sendMessage($normalizedPhone, $message, true, $attachment);

        if ($response['success']) {
            Database::updateLog($logId, 'sent', $response['data'] ?? null, null);
        } else {
            Database::updateLog($logId, 'failed', $response['data'] ?? null, $response['message'] ?? 'Send failed');
        }

        return $response;
    }

    /**
     * Helper: Get Company Name from WHMCS configuration
     */
    public static function getCompanyName(): string
    {
        try {
            $val = Capsule::table('tblconfiguration')->where('setting', 'CompanyName')->value('value');
            return !empty($val) ? $val : 'WHMCS Service Provider';
        } catch (\Throwable $e) {
            return 'WHMCS';
        }
    }

    /**
     * Helper: Get System URL from WHMCS configuration
     */
    public static function getSystemUrl(): string
    {
        try {
            $val = Capsule::table('tblconfiguration')->where('setting', 'SystemURL')->value('value');
            return !empty($val) ? rtrim($val, '/') : 'http://localhost';
        } catch (\Throwable $e) {
            return 'http://localhost';
        }
    }
}
