<?php

namespace LeadWhatsApp;

use WHMCS\Database\Capsule;

/**
 * Database Management and Query Service for LeadWhatsApp WHMCS Module
 */
class Database
{
    /**
     * Create all module database tables
     */
    public static function createTables(): void
    {
        $schema = Capsule::schema();

        // 1. Templates Table
        if (!$schema->hasTable('mod_leadwhatsapp_templates')) {
            $schema->create('mod_leadwhatsapp_templates', function ($table) {
                $table->increments('id');
                $table->string('event_key', 64)->unique();
                $table->string('category', 64)->default('General');
                $table->string('name', 128);
                $table->text('description')->nullable();
                $table->text('template_text');
                $table->text('variables')->nullable();
                $table->boolean('is_active')->default(1);
                $table->boolean('send_to_admin')->default(0);
                $table->timestamps();
            });
        }

        // 2. Message Audit Logs Table
        if (!$schema->hasTable('mod_leadwhatsapp_logs')) {
            $schema->create('mod_leadwhatsapp_logs', function ($table) {
                $table->increments('id');
                $table->string('rel_type', 32)->nullable()->index(); // invoice, ticket, client, service, domain, 2fa, custom
                $table->integer('rel_id')->nullable()->index();
                $table->string('recipient_phone', 32)->index();
                $table->integer('client_id')->nullable()->index();
                $table->string('event_key', 64)->nullable();
                $table->text('message_text');
                $table->enum('status', ['sent', 'failed', 'pending'])->default('pending');
                $table->text('response_data')->nullable();
                $table->text('error_message')->nullable();
                $table->timestamp('created_at')->useCurrent()->index();
            });
        }

        // 3. OTP & 2FA Sessions Table
        if (!$schema->hasTable('mod_leadwhatsapp_otp')) {
            $schema->create('mod_leadwhatsapp_otp', function ($table) {
                $table->increments('id');
                $table->integer('user_id')->index();
                $table->enum('user_type', ['client', 'admin'])->default('client');
                $table->string('phone', 32);
                $table->string('otp_code', 16);
                $table->dateTime('expires_at')->index();
                $table->boolean('is_verified')->default(0);
                $table->timestamps();
            });
        }

        // 4. Custom Module Settings / KV Table
        if (!$schema->hasTable('mod_leadwhatsapp_settings')) {
            $schema->create('mod_leadwhatsapp_settings', function ($table) {
                $table->increments('id');
                $table->string('setting', 64)->unique();
                $table->text('value')->nullable();
            });
        }

        self::seedDefaultTemplates();
    }

    /**
     * Drop module tables upon deactivation if desired
     */
    public static function dropTables(): void
    {
        $schema = Capsule::schema();
        $schema->dropIfExists('mod_leadwhatsapp_otp');
        $schema->dropIfExists('mod_leadwhatsapp_logs');
        $schema->dropIfExists('mod_leadwhatsapp_templates');
        $schema->dropIfExists('mod_leadwhatsapp_settings');
    }

    /**
     * Seed or update default notification templates
     */
    public static function seedDefaultTemplates(): void
    {
        $file = dirname(__DIR__) . '/config/default_templates.php';
        if (!file_exists($file)) {
            return;
        }

        $templates = require $file;
        $now = date('Y-m-d H:i:s');

        foreach ($templates as $tpl) {
            $exists = Capsule::table('mod_leadwhatsapp_templates')
                ->where('event_key', $tpl['event_key'])
                ->first();

            if (!$exists) {
                Capsule::table('mod_leadwhatsapp_templates')->insert([
                    'event_key' => $tpl['event_key'],
                    'category' => $tpl['category'],
                    'name' => $tpl['name'],
                    'description' => $tpl['description'],
                    'template_text' => $tpl['template_text'],
                    'variables' => $tpl['variables'],
                    'is_active' => 1,
                    'send_to_admin' => $tpl['send_to_admin'] ?? 0,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        }
    }

    /**
     * Retrieve configuration values from WHMCS tbladdonmodules
     */
    public static function getModuleConfig(): array
    {
        $config = [];
        try {
            $rows = Capsule::table('tbladdonmodules')
                ->where('module', 'leadwhatsapp')
                ->get();

            foreach ($rows as $row) {
                $config[$row->setting] = $row->value;
            }
        } catch (\Throwable $e) {
            // WHMCS DB not available or table does not exist
        }

        return $config;
    }

    /**
     * Save or update module configuration in tbladdonmodules
     */
    public static function saveModuleConfig(array $settings): bool
    {
        try {
            foreach ($settings as $settingKey => $settingVal) {
                Capsule::table('tbladdonmodules')->updateOrInsert(
                    ['module' => 'leadwhatsapp', 'setting' => $settingKey],
                    ['value' => (string)$settingVal]
                );
            }
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Get single template by event key
     */
    public static function getTemplate(string $eventKey): ?object
    {
        try {
            return Capsule::table('mod_leadwhatsapp_templates')
                ->where('event_key', $eventKey)
                ->first();
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Get all templates grouped or filtered
     */
    public static function getAllTemplates(): array
    {
        try {
            return Capsule::table('mod_leadwhatsapp_templates')
                ->orderBy('category', 'asc')
                ->orderBy('name', 'asc')
                ->get()
                ->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Save / Update template
     */
    public static function updateTemplate(int $id, array $data): bool
    {
        try {
            $data['updated_at'] = date('Y-m-d H:i:s');
            Capsule::table('mod_leadwhatsapp_templates')
                ->where('id', $id)
                ->update($data);
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Record a message log entry
     */
    public static function logMessage(array $data): int
    {
        try {
            return Capsule::table('mod_leadwhatsapp_logs')->insertGetId([
                'rel_type' => $data['rel_type'] ?? null,
                'rel_id' => $data['rel_id'] ?? null,
                'recipient_phone' => $data['recipient_phone'] ?? '',
                'client_id' => $data['client_id'] ?? null,
                'event_key' => $data['event_key'] ?? null,
                'message_text' => $data['message_text'] ?? '',
                'status' => $data['status'] ?? 'pending',
                'response_data' => isset($data['response_data']) ? (is_string($data['response_data']) ? $data['response_data'] : json_encode($data['response_data'])) : null,
                'error_message' => $data['error_message'] ?? null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Update an existing log entry status
     */
    public static function updateLog(int $logId, string $status, ?array $response = null, ?string $error = null): void
    {
        try {
            $update = ['status' => $status];
            if ($response !== null) {
                $update['response_data'] = json_encode($response);
            }
            if ($error !== null) {
                $update['error_message'] = $error;
            }
            Capsule::table('mod_leadwhatsapp_logs')
                ->where('id', $logId)
                ->update($update);
        } catch (\Throwable $e) {
            // Ignore
        }
    }

    /**
     * Fetch logs with pagination & filtering
     */
    public static function getLogs(int $limit = 20, int $offset = 0, array $filters = []): array
    {
        try {
            $query = Capsule::table('mod_leadwhatsapp_logs');

            if (!empty($filters['status'])) {
                $query->where('status', $filters['status']);
            }
            if (!empty($filters['phone'])) {
                $query->where('recipient_phone', 'like', '%' . $filters['phone'] . '%');
            }
            if (!empty($filters['event_key'])) {
                $query->where('event_key', $filters['event_key']);
            }
            if (!empty($filters['search'])) {
                $query->where(function ($q) use ($filters) {
                    $q->where('recipient_phone', 'like', '%' . $filters['search'] . '%')
                      ->orWhere('message_text', 'like', '%' . $filters['search'] . '%');
                });
            }

            $total = $query->count();
            $items = $query->orderBy('id', 'desc')->skip($offset)->take($limit)->get()->toArray();

            return [
                'total' => $total,
                'items' => $items,
            ];
        } catch (\Throwable $e) {
            return ['total' => 0, 'items' => []];
        }
    }

    /**
     * Get Dashboard Summary Statistics
     */
    public static function getStatistics(): array
    {
        try {
            $totalSent = Capsule::table('mod_leadwhatsapp_logs')->where('status', 'sent')->count();
            $totalFailed = Capsule::table('mod_leadwhatsapp_logs')->where('status', 'failed')->count();
            $todaySent = Capsule::table('mod_leadwhatsapp_logs')
                ->where('status', 'sent')
                ->where('created_at', '>=', date('Y-m-d 00:00:00'))
                ->count();
            $activeTemplates = Capsule::table('mod_leadwhatsapp_templates')->where('is_active', 1)->count();

            return [
                'total_sent' => $totalSent,
                'total_failed' => $totalFailed,
                'today_sent' => $todaySent,
                'active_templates' => $activeTemplates,
            ];
        } catch (\Throwable $e) {
            return [
                'total_sent' => 0,
                'total_failed' => 0,
                'today_sent' => 0,
                'active_templates' => 0,
            ];
        }
    }

    /**
     * Store 2FA OTP verification code
     */
    public static function createOtpSession(int $userId, string $userType, string $phone, string $otp, int $expiresMinutes = 5): int
    {
        try {
            $expiresAt = date('Y-m-d H:i:s', time() + ($expiresMinutes * 60));
            // Invalidate older unverified OTPs for this user
            Capsule::table('mod_leadwhatsapp_otp')
                ->where('user_id', $userId)
                ->where('user_type', $userType)
                ->where('is_verified', 0)
                ->delete();

            return Capsule::table('mod_leadwhatsapp_otp')->insertGetId([
                'user_id' => $userId,
                'user_type' => $userType,
                'phone' => $phone,
                'otp_code' => $otp,
                'expires_at' => $expiresAt,
                'is_verified' => 0,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Verify OTP code for user
     */
    public static function verifyOtp(int $userId, string $userType, string $otp): bool
    {
        try {
            $now = date('Y-m-d H:i:s');
            $record = Capsule::table('mod_leadwhatsapp_otp')
                ->where('user_id', $userId)
                ->where('user_type', $userType)
                ->where('otp_code', trim($otp))
                ->where('is_verified', 0)
                ->where('expires_at', '>=', $now)
                ->orderBy('id', 'desc')
                ->first();

            if ($record) {
                Capsule::table('mod_leadwhatsapp_otp')
                    ->where('id', $record->id)
                    ->update(['is_verified' => 1, 'updated_at' => $now]);
                return true;
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Get or Set Key-Value setting
     */
    public static function getSetting(string $key, $default = null)
    {
        try {
            $record = Capsule::table('mod_leadwhatsapp_settings')->where('setting', $key)->first();
            return $record ? $record->value : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    public static function setSetting(string $key, string $value): void
    {
        try {
            Capsule::table('mod_leadwhatsapp_settings')->updateOrInsert(
                ['setting' => $key],
                ['value' => $value]
            );
        } catch (\Throwable $e) {
            // Ignore
        }
    }
}
