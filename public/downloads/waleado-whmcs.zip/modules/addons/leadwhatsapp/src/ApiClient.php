<?php

namespace LeadWhatsApp;

/**
 * LeadWhatsApp Open API Client for WHMCS
 * Connects to LeadWhatsApp backend to send WhatsApp messages and inspect device status.
 */
class ApiClient
{
    private string $baseUrl;
    private string $clientId;
    private string $clientSecret;
    private int $timeout;
    private bool $debug;

    public function __construct(string $baseUrl = '', string $clientId = '', string $clientSecret = '', int $timeout = 15, bool $debug = false)
    {
        $this->baseUrl = rtrim(trim($baseUrl), '/');
        $this->clientId = trim($clientId);
        $this->clientSecret = trim($clientSecret);
        $this->timeout = $timeout;
        $this->debug = $debug;
    }

    /**
     * Factory instance from WHMCS Module configuration
     */
    public static function fromConfig(): self
    {
        $config = Database::getModuleConfig();
        $apiUrl = $config['api_url'] ?? 'https://leadwhatsappapi.flexsoftr.com';
        $clientId = $config['client_id'] ?? '';
        $clientSecret = $config['client_secret'] ?? '';
        $debug = ($config['debug_log'] ?? '') === 'on';

        return new self($apiUrl, $clientId, $clientSecret, 15, $debug);
    }

    /**
     * Send a single WhatsApp message (text or document/media attachment)
     * Verifies that the recipient number is a valid WhatsApp number before dispatching.
     * Endpoint: POST /v1/open/messages/single
     */
    public function sendMessage(string $toPhone, string $bodyText, bool $verifyFirst = true, ?array $attachment = null): array
    {
        if (empty($this->clientId) || empty($this->clientSecret)) {
            return [
                'success' => false,
                'message' => 'LeadWhatsApp API credentials (Client ID or Client Secret) are not configured.',
                'error' => 'MISSING_CREDENTIALS',
                'data' => null,
            ];
        }

        if (empty($toPhone)) {
            return [
                'success' => false,
                'message' => 'Recipient phone number cannot be empty.',
                'error' => 'INVALID_INPUT',
                'data' => null,
            ];
        }

        $normalizedPhone = PhoneHelper::normalize($toPhone);
        if (empty($normalizedPhone) || !PhoneHelper::isValid($normalizedPhone)) {
            return [
                'success' => false,
                'message' => "Recipient phone number '{$toPhone}' is invalid. Please provide a valid international number with country code.",
                'error' => 'INVALID_PHONE_FORMAT',
                'data' => null,
            ];
        }

        // Verify that the number is a valid WhatsApp number before sending if enabled
        $config = Database::getModuleConfig();
        $verifyEnabled = ($config['verify_whatsapp_number'] ?? 'on') !== 'off';

        if ($verifyFirst && $verifyEnabled) {
            $validation = $this->validatePhone($normalizedPhone);
            if (!$validation['success']) {
                return [
                    'success' => false,
                    'message' => 'WhatsApp verification failed: ' . ($validation['message'] ?? 'Number is not registered on WhatsApp.'),
                    'error' => $validation['error'] ?? 'INVALID_WHATSAPP_NUMBER',
                    'data' => $validation['data'] ?? null,
                ];
            }

            if (!empty($validation['data']['phone'])) {
                $normalizedPhone = $validation['data']['phone'];
            }
        }

        $payload = [
            'toPhone' => $normalizedPhone,
            'bodyText' => $bodyText,
        ];

        if (!empty($attachment)) {
            if (!empty($attachment['fileData']) || !empty($attachment['fileBase64'])) {
                $payload['fileBase64'] = $attachment['fileData'] ?? $attachment['fileBase64'];
            }
            if (!empty($attachment['fileUrl']) || !empty($attachment['mediaUrl'])) {
                $payload['fileUrl'] = $attachment['fileUrl'] ?? $attachment['mediaUrl'];
            }
            if (!empty($attachment['fileName'])) {
                $payload['fileName'] = $attachment['fileName'];
            }
            if (!empty($attachment['mimeType'])) {
                $payload['mimeType'] = $attachment['mimeType'];
            }
        }

        return $this->request('POST', '/v1/open/messages/single', $payload);
    }

    /**
     * Send a document or media file via WhatsApp
     */
    public function sendMedia(
        string $toPhone,
        string $caption = '',
        ?string $fileData = null,
        ?string $fileUrl = null,
        ?string $fileName = null,
        ?string $mimeType = 'application/pdf',
        bool $verifyFirst = true
    ): array {
        $attachment = [
            'fileData' => $fileData,
            'fileUrl' => $fileUrl,
            'fileName' => $fileName,
            'mimeType' => $mimeType,
        ];

        return $this->sendMessage($toPhone, $caption, $verifyFirst, $attachment);
    }

    /**
     * Validate and verify whether a phone number is registered on WhatsApp
     * Endpoint: POST /v1/open/messages/validate-phone
     */
    public function validatePhone(string $phone): array
    {
        $normalized = PhoneHelper::normalize($phone);
        if (empty($normalized) || !PhoneHelper::isValid($normalized)) {
            return [
                'success' => false,
                'message' => "Invalid phone number format: '{$phone}'. A valid international number with country code is required (e.g. +88017XXXXXXXX).",
                'error' => 'INVALID_PHONE_FORMAT',
                'data' => [
                    'valid' => false,
                    'phone' => $normalized ?: $phone,
                ],
            ];
        }

        if (empty($this->clientId) || empty($this->clientSecret)) {
            return [
                'success' => false,
                'message' => 'LeadWhatsApp API credentials (Client ID or Client Secret) are not configured.',
                'error' => 'MISSING_CREDENTIALS',
                'data' => [
                    'valid' => false,
                    'phone' => $normalized,
                ],
            ];
        }

        $response = $this->request('POST', '/v1/open/messages/validate-phone', ['phone' => $normalized]);

        if ($response['success']) {
            $data = (array)($response['data'] ?? []);
            $isValidWhatsApp = true;

            if (isset($data['valid']) && !$data['valid']) {
                $isValidWhatsApp = false;
            } elseif (isset($data['exists']) && !$data['exists']) {
                $isValidWhatsApp = false;
            } elseif (isset($data['isWhatsApp']) && !$data['isWhatsApp']) {
                $isValidWhatsApp = false;
            } elseif (isset($data['is_whatsapp']) && !$data['is_whatsapp']) {
                $isValidWhatsApp = false;
            } elseif (isset($data['registered']) && !$data['registered']) {
                $isValidWhatsApp = false;
            }

            if (!$isValidWhatsApp) {
                return [
                    'success' => false,
                    'message' => $response['message'] ?? "Phone number '{$normalized}' is not registered on WhatsApp.",
                    'error' => 'NOT_WHATSAPP_USER',
                    'data' => array_merge($data, ['valid' => false, 'phone' => $normalized]),
                ];
            }

            return [
                'success' => true,
                'message' => $response['message'] ?? "Phone number '{$normalized}' is a valid WhatsApp number.",
                'data' => array_merge($data, ['valid' => true, 'phone' => $normalized]),
                'error' => null,
            ];
        }

        return $response;
    }

    /**
     * List WhatsApp devices connected to the workspace
     * Endpoint: GET /v1/open/devices
     */
    public function getDevices(): array
    {
        return $this->request('GET', '/v1/open/devices');
    }

    /**
     * Test API connection and verify if a default device is connected
     */
    public function testConnection(): array
    {
        $response = $this->getDevices();
        if (!$response['success']) {
            return [
                'success' => false,
                'message' => $response['message'] ?? 'Failed to connect to LeadWhatsApp API.',
                'error' => $response['error'] ?? 'CONNECTION_FAILED',
                'data' => null,
            ];
        }

        $devices = $response['data']['devices'] ?? [];
        $defaultDevice = null;
        $connectedCount = 0;

        foreach ($devices as $d) {
            if (!empty($d['isDefault'])) {
                $defaultDevice = $d;
            }
            if (($d['status'] ?? '') === 'connected') {
                $connectedCount++;
            }
        }

        return [
            'success' => true,
            'message' => 'Successfully connected to LeadWhatsApp API!',
            'data' => [
                'total_devices' => count($devices),
                'connected_devices' => $connectedCount,
                'default_device' => $defaultDevice,
                'has_default' => !empty($defaultDevice),
            ],
            'error' => null,
        ];
    }

    /**
     * Execute HTTP request to LeadWhatsApp Open API
     */
    private function request(string $method, string $endpoint, ?array $data = null): array
    {
        $url = $this->baseUrl . $endpoint;

        $headers = [
            'X-Client-Id: ' . $this->clientId,
            'X-Client-Secret: ' . $this->clientSecret,
            'Content-Type: application/json',
            'Accept: application/json',
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        if (strtoupper($method) === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif (strtoupper($method) === 'GET') {
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        } else {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }

        $responseBody = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        $curlErrno = curl_errno($ch);
        curl_close($ch);

        if ($this->debug && function_exists('logActivity')) {
            logActivity("[LeadWhatsApp Debug] {$method} {$url} -> HTTP {$httpCode} : " . substr((string)$responseBody, 0, 500));
        }

        if ($curlErrno !== 0) {
            return [
                'success' => false,
                'message' => 'Network error connecting to LeadWhatsApp: ' . $curlError,
                'error' => 'CURL_ERROR_' . $curlErrno,
                'data' => null,
            ];
        }

        $decoded = json_decode((string)$responseBody, true);

        if (!is_array($decoded)) {
            return [
                'success' => false,
                'message' => "Invalid response from server (HTTP {$httpCode}). Output: " . substr(strip_tags((string)$responseBody), 0, 200),
                'error' => 'INVALID_JSON_RESPONSE',
                'data' => null,
            ];
        }

        if ($httpCode >= 200 && $httpCode < 300) {
            return [
                'success' => $decoded['success'] ?? true,
                'message' => $decoded['message'] ?? 'Success',
                'data' => $decoded['data'] ?? null,
                'error' => null,
            ];
        }

        return [
            'success' => false,
            'message' => $decoded['message'] ?? "Request failed with HTTP {$httpCode}",
            'error' => $decoded['error'] ?? 'API_ERROR_' . $httpCode,
            'data' => $decoded['data'] ?? null,
            'errors' => $decoded['errors'] ?? null,
        ];
    }
}
