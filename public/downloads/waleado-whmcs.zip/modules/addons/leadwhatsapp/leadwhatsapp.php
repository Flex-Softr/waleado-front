<?php
/**
 * LeadWhatsApp Integration Module for WHMCS
 *
 * @package    WHMCS
 * @author     LeadWhatsApp
 * @copyright  Copyright (c) LeadWhatsApp 2026
 * @link       https://leadwhats.app
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

// Autoloader fallback
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
} else {
    spl_autoload_register(function ($class) {
        $prefix = 'LeadWhatsApp\\';
        $baseDir = __DIR__ . '/src/';
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    });
}

use LeadWhatsApp\Database;
use LeadWhatsApp\AdminController;

/**
 * Module Configuration
 */
function leadwhatsapp_config(): array
{
    return [
        'name' => 'LeadWhatsApp Suite',
        'description' => 'Automated WhatsApp Notifications, Invoices, Tickets, System Alerts & 2FA Verification via LeadWhatsApp API.',
        'version' => '1.2.1',
        'author' => '<a href="https://leadwhats.app" target="_blank">LeadWhatsApp</a>',
        'language' => 'english',
        'fields' => [
            'api_url' => [
                'FriendlyName' => 'LeadWhatsApp API URL',
                'Type' => 'text',
                'Size' => '50',
                'Default' => 'http://localhost:3000',
                'Description' => 'The base URL where your LeadWhatsApp backend/API is hosted (e.g. <code>https://api.yourdomain.com</code> or <code>http://localhost:3000</code>).',
            ],
            'client_id' => [
                'FriendlyName' => 'API Client ID',
                'Type' => 'text',
                'Size' => '40',
                'Default' => '',
                'Description' => 'Your LeadWhatsApp API Client ID (<code>fw_cid_...</code>). Created in the LeadWhatsApp API Credentials dashboard.',
            ],
            'client_secret' => [
                'FriendlyName' => 'API Client Secret',
                'Type' => 'password',
                'Size' => '50',
                'Default' => '',
                'Description' => 'Your LeadWhatsApp API Client Secret (<code>fw_csec_...</code>).',
            ],
            'admin_phone' => [
                'FriendlyName' => 'Admin WhatsApp Number',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Mobile number with country code (e.g. <code>+88017XXXXXXXX</code>) to receive Admin Alerts.',
            ],
            'default_country_code' => [
                'FriendlyName' => 'Default Country Dial Code',
                'Type' => 'text',
                'Size' => '6',
                'Default' => '880',
                'Description' => 'Default international country calling code without "+" (e.g. <code>880</code> for Bangladesh, <code>1</code> for USA/Canada, <code>44</code> for UK).',
            ],
            'custom_phone_field' => [
                'FriendlyName' => 'Custom Field for WhatsApp Phone (Optional)',
                'Type' => 'text',
                'Size' => '30',
                'Default' => '',
                'Description' => 'If you have a dedicated client custom field for WhatsApp numbers, enter its name here (e.g. <code>WhatsApp Number</code>).',
            ],
            'attach_invoice_pdf' => [
                'FriendlyName' => 'Attach Invoice PDF',
                'Type' => 'yesno',
                'Default' => 'on',
                'Description' => 'Automatically attach generated PDF invoices to WhatsApp invoice notifications (purchases, renewals, payment reminders).',
            ],
            'verify_whatsapp_number' => [
                'FriendlyName' => 'Verify WhatsApp Number',
                'Type' => 'yesno',
                'Default' => 'on',
                'Description' => 'Automatically verify that recipient phone numbers are registered on WhatsApp before dispatching messages.',
            ],
            'debug_log' => [
                'FriendlyName' => 'Debug Logging',
                'Type' => 'yesno',
                'Description' => 'Enable detailed API request and response logging to WHMCS Activity Log.',
            ],
        ],
    ];
}

/**
 * Module Activation
 */
function leadwhatsapp_activate(): array
{
    try {
        Database::createTables();
        return [
            'status' => 'success',
            'description' => 'LeadWhatsApp module activated successfully! Database tables and default notification templates have been initialized.',
        ];
    } catch (\Throwable $e) {
        return [
            'status' => 'error',
            'description' => 'Failed to initialize database tables: ' . $e->getMessage(),
        ];
    }
}

/**
 * Module Deactivation
 */
function leadwhatsapp_deactivate(): array
{
    return [
        'status' => 'success',
        'description' => 'LeadWhatsApp module has been deactivated. Data tables have been preserved.',
    ];
}

/**
 * Module Upgrade
 */
function leadwhatsapp_upgrade(array $vars): void
{
    Database::createTables();
}

/**
 * Module Admin Area Output
 */
function leadwhatsapp_output(array $vars): void
{
    echo AdminController::handle($vars);
}

/**
 * Client Area Output (Optional)
 */
function leadwhatsapp_clientarea(array $vars): array
{
    return [
        'pagetitle' => 'WhatsApp Notifications',
        'breadcrumb' => ['index.php?m=leadwhatsapp' => 'WhatsApp Notifications'],
        'templatefile' => 'clientarea',
        'requirelogin' => true,
        'vars' => [
            'companyName' => \LeadWhatsApp\TemplateService::getCompanyName(),
        ],
    ];
}
