<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

// Require autoloader if present or manually include core classes
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
} else {
    spl_autoload_register(function ($class) {
        $prefix = 'LeadWhatsApp\\';
        $baseDir = __DIR__ . '/src/';
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    });
}

use LeadWhatsApp\Hooks\ClientHooks;
use LeadWhatsApp\Hooks\InvoiceHooks;
use LeadWhatsApp\Hooks\ServiceHooks;
use LeadWhatsApp\Hooks\DomainHooks;
use LeadWhatsApp\Hooks\TicketHooks;
use LeadWhatsApp\Hooks\CronHooks;

// --- Client Hooks ---
add_hook('ClientAdd', 1, function ($vars) {
    ClientHooks::onClientAdd($vars);
});

add_hook('ClientLogin', 1, function ($vars) {
    ClientHooks::onClientLogin($vars);
});

add_hook('AdminLogin', 1, function ($vars) {
    ClientHooks::onAdminLogin($vars);
});

add_hook('ClientChangePassword', 1, function ($vars) {
    ClientHooks::onClientChangePassword($vars);
});

// --- Invoice Hooks ---
add_hook('InvoiceCreated', 1, function ($vars) {
    InvoiceHooks::onInvoiceCreated($vars);
});

add_hook('InvoicePaid', 1, function ($vars) {
    InvoiceHooks::onInvoicePaid($vars);
});

add_hook('InvoicePaymentReminder', 1, function ($vars) {
    InvoiceHooks::onInvoicePaymentReminder($vars);
});

add_hook('InvoiceRefunded', 1, function ($vars) {
    InvoiceHooks::onInvoiceRefunded($vars);
});

add_hook('InvoiceCancelled', 1, function ($vars) {
    InvoiceHooks::onInvoiceCancelled($vars);
});

// --- Service & Order Hooks ---
add_hook('AcceptOrder', 1, function ($vars) {
    ServiceHooks::onAcceptOrder($vars);
});

add_hook('AfterModuleCreate', 1, function ($vars) {
    ServiceHooks::onAfterModuleCreate($vars);
});

add_hook('AfterModuleSuspend', 1, function ($vars) {
    ServiceHooks::onAfterModuleSuspend($vars);
});

add_hook('AfterModuleUnsuspend', 1, function ($vars) {
    ServiceHooks::onAfterModuleUnsuspend($vars);
});

// --- Domain Hooks ---
add_hook('AfterRegistrarRegistration', 1, function ($vars) {
    DomainHooks::onDomainRegistered($vars);
});

add_hook('AfterRegistrarRenewal', 1, function ($vars) {
    DomainHooks::onDomainRenewed($vars);
});

add_hook('DomainRenewalNotice', 1, function ($vars) {
    DomainHooks::onDomainRenewalNotice($vars);
});

// --- Ticket Hooks ---
add_hook('TicketOpen', 1, function ($vars) {
    TicketHooks::onTicketOpen($vars);
});

add_hook('TicketAdminReply', 1, function ($vars) {
    TicketHooks::onTicketAdminReply($vars);
});

add_hook('TicketUserReply', 1, function ($vars) {
    TicketHooks::onTicketUserReply($vars);
});

add_hook('TicketClose', 1, function ($vars) {
    TicketHooks::onTicketClose($vars);
});

// --- Automation & Cron ---
add_hook('DailyCronJob', 1, function ($vars) {
    CronHooks::onDailyCronJob($vars);
});

// --- Admin Quick Action in Client Summary ---
add_hook('AdminAreaClientSummaryActionLinks', 1, function ($vars) {
    $userid = (int)$vars['userid'];
    return [
        '<a href="addonmodules.php?module=leadwhatsapp&tab=send_test&client_id=' . $userid . '" class="btn btn-default btn-sm" title="Send WhatsApp Message"><i class="fab fa-whatsapp" style="color: #25D366; font-weight:bold;"></i> Send WhatsApp</a>',
    ];
});
