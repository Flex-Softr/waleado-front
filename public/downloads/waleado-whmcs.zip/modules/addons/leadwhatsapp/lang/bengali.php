<?php

$_ADDONLANG['title'] = "লিডহোয়াটসঅ্যাপ সুইট";
$_ADDONLANG['description'] = "WHMCS এর জন্য স্বয়ংক্রিয় হোয়াটসঅ্যাপ নোটিফিকেশন, ইনভয়েস অ্যালার্ট, সাপোর্ট টিকিট আপডেট এবং টু-ফ্যাক্টর অথেনটিকেশন";
$_ADDONLANG['dashboard'] = "ড্যাশবোর্ড";
$_ADDONLANG['templates'] = "টেমপ্লেটসমূহ";
$_ADDONLANG['logs'] = "মেসেজ লগ";
$_ADDONLANG['send_test'] = "মেসেজ পাঠান";
$_ADDONLANG['settings'] = "সেটিংস";
$_ADDONLANG['total_sent'] = "মোট পাঠানো হয়েছে";
$_ADDONLANG['total_failed'] = "ব্যর্থ হয়েছে";
$_ADDONLANG['today_sent'] = "আজকে পাঠানো";
$_ADDONLANG['active_templates'] = "সক্রিয় টেমপ্লেট";
$_ADDONLANG['save_success'] = "টেমপ্লেট সফলভাবে সংরক্ষিত হয়েছে!";
$_ADDONLANG['send_success'] = "হোয়াটসঅ্যাপ মেসেজ সফলভাবে পাঠানো হয়েছে!";
$_ADDONLANG['send_failed'] = "হোয়াটসঅ্যাপ মেসেজ পাঠাতে ব্যর্থ হয়েছে।";
