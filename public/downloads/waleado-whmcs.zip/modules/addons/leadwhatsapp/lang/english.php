<?php

$_ADDONLANG['title'] = "LeadWhatsApp Suite";
$_ADDONLANG['description'] = "Automated WhatsApp notifications, billing alerts, support ticket updates & 2FA OTP verification for WHMCS";
$_ADDONLANG['dashboard'] = "Dashboard";
$_ADDONLANG['templates'] = "Notification Templates";
$_ADDONLANG['logs'] = "Message Logs";
$_ADDONLANG['send_test'] = "Send Message";
$_ADDONLANG['settings'] = "Settings";
$_ADDONLANG['total_sent'] = "Total Sent";
$_ADDONLANG['total_failed'] = "Total Failed";
$_ADDONLANG['today_sent'] = "Sent Today";
$_ADDONLANG['active_templates'] = "Active Templates";
$_ADDONLANG['save_success'] = "Template saved successfully!";
$_ADDONLANG['send_success'] = "Message sent successfully via WhatsApp!";
$_ADDONLANG['send_failed'] = "Failed to dispatch WhatsApp message.";
