<?php
/**
 * LeadWhatsApp WHMCS Module Admin Layout
 */
$tab = $tab ?? 'dashboard';
?>
<style>
.leadwa-container {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #1e293b;
    margin-top: 15px;
}
.leadwa-header {
    background: linear-gradient(135deg, #059669 0%, #10b981 50%, #047857 100%);
    color: #ffffff;
    padding: 24px 28px;
    border-radius: 12px;
    box-shadow: 0 4px 14px rgba(16, 185, 129, 0.25);
    margin-bottom: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}
.leadwa-header h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0;
    color: #ffffff;
    display: flex;
    align-items: center;
    gap: 12px;
}
.leadwa-header p {
    margin: 6px 0 0 0;
    color: #d1fae5;
    font-size: 14px;
}
.leadwa-badge {
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    padding: 6px 14px;
    border-radius: 9999px;
    font-size: 13px;
    font-weight: 600;
    color: #ffffff;
}
.leadwa-nav {
    display: flex;
    gap: 8px;
    background: #ffffff;
    padding: 8px;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    margin-bottom: 24px;
    flex-wrap: wrap;
}
.leadwa-nav-item {
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    color: #64748b;
    text-decoration: none !important;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
}
.leadwa-nav-item:hover {
    background: #f1f5f9;
    color: #0f172a;
}
.leadwa-nav-item.active {
    background: #10b981;
    color: #ffffff;
    box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}
.leadwa-card {
    background: #ffffff;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    margin-bottom: 24px;
    overflow: hidden;
}
.leadwa-card-header {
    padding: 18px 24px;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.leadwa-card-header h3 {
    font-size: 16px;
    font-weight: 700;
    margin: 0;
    color: #0f172a;
    display: flex;
    align-items: center;
    gap: 10px;
}
.leadwa-card-body {
    padding: 24px;
}
.leadwa-stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.leadwa-stat-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
}
.leadwa-stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}
.leadwa-stat-info h4 {
    margin: 0;
    font-size: 13px;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.leadwa-stat-info .stat-number {
    font-size: 24px;
    font-weight: 800;
    color: #0f172a;
    margin: 4px 0 0 0;
}
.leadwa-tag {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-family: monospace;
    cursor: pointer;
    background: #e0e7ff;
    color: #3730a3;
    border: 1px solid #c7d2fe;
    margin: 2px;
    user-select: all;
    transition: transform 0.1s;
}
.leadwa-tag:hover {
    transform: scale(1.05);
    background: #c7d2fe;
}
.leadwa-status-pill {
    padding: 4px 10px;
    border-radius: 9999px;
    font-size: 12px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.leadwa-status-pill.sent { background: #dcfce7; color: #15803d; }
.leadwa-status-pill.failed { background: #fee2e2; color: #b91c1c; }
.leadwa-status-pill.pending { background: #fef9c3; color: #a16207; }

/* Toggle Switch Slider */
.leadwa-switch {
    position: relative;
    display: inline-block;
    width: 44px;
    height: 24px;
    margin: 0;
    cursor: pointer;
    user-select: none;
    vertical-align: middle;
}
.leadwa-switch input {
    opacity: 0;
    width: 0;
    height: 0;
    position: absolute;
}
.leadwa-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #cbd5e1;
    transition: all 0.3s ease;
    border-radius: 24px;
}
.leadwa-slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
    background-color: #ffffff;
    transition: all 0.3s ease;
    border-radius: 50%;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}
input:checked + .leadwa-slider {
    background-color: #10b981;
}
input:focus + .leadwa-slider {
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
}
input:checked + .leadwa-slider:before {
    transform: translateX(20px);
}
.leadwa-badge-status {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transition: all 0.2s;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}
.leadwa-badge-status.active {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #bbf7d0;
}
.leadwa-badge-status.inactive {
    background: #f1f5f9;
    color: #64748b;
    border: 1px solid #e2e8f0;
}
.leadwa-template-row {
    padding: 20px 24px;
    transition: background-color 0.2s ease, opacity 0.2s ease;
}
.leadwa-template-row.disabled-template {
    background-color: #f8fafc;
    opacity: 0.88;
}
.leadwa-toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 999999;
    background: #0f172a;
    color: #ffffff;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.25);
    font-size: 13px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    transform: translateY(100px);
    opacity: 0;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.leadwa-toast.show {
    transform: translateY(0);
    opacity: 1;
}
.leadwa-toast.success i { color: #34d399; }
.leadwa-toast.error i { color: #f87171; }

/* Test Sender Mode Switcher & Controls */
.leadwa-mode-tabs {
    display: flex;
    gap: 10px;
    background: #f1f5f9;
    padding: 6px;
    border-radius: 10px;
    margin-bottom: 20px;
}
.leadwa-mode-tab {
    flex: 1;
    text-align: center;
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    background: transparent;
    color: #64748b;
    border: none;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.leadwa-mode-tab:hover {
    color: #0f172a;
    background: rgba(255, 255, 255, 0.6);
}
.leadwa-mode-tab.active {
    background: #ffffff;
    color: #059669;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}
.leadwa-phone-group {
    display: flex !important;
    flex-direction: row !important;
    flex-wrap: nowrap !important;
    align-items: stretch !important;
    width: 100% !important;
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 8px !important;
    position: relative !important;
    overflow: visible !important;
    transition: border-color 0.2s, box-shadow 0.2s;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04) !important;
    min-height: 42px !important;
    box-sizing: border-box !important;
}
.leadwa-phone-group:focus-within {
    border-color: #10b981 !important;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15) !important;
}
.leadwa-country-picker-wrap {
    position: relative !important;
    flex: 0 0 auto !important;
    display: flex !important;
    align-items: stretch !important;
}
.leadwa-country-picker-btn {
    display: inline-flex !important;
    align-items: center !important;
    gap: 7px !important;
    background: #f8fafc !important;
    border: none !important;
    border-right: 1px solid #e2e8f0 !important;
    padding: 0 14px !important;
    color: #334155 !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    border-top-left-radius: 7px !important;
    border-bottom-left-radius: 7px !important;
    transition: background 0.15s ease, color 0.15s ease !important;
    user-select: none !important;
    outline: none !important;
    white-space: nowrap !important;
    margin: 0 !important;
    height: auto !important;
    box-sizing: border-box !important;
}
.leadwa-country-picker-btn:hover,
.leadwa-country-picker-btn:focus,
.leadwa-country-picker-btn.open {
    background: #f1f5f9 !important;
    color: #0f172a !important;
}
.leadwa-flag-icon {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: 20px !important;
    height: 15px !important;
    flex-shrink: 0 !important;
    overflow: hidden !important;
    border-radius: 2px !important;
    box-shadow: 0 0 1px rgba(0, 0, 0, 0.25) !important;
    line-height: 1 !important;
}
.leadwa-flag-icon img {
    display: block !important;
    width: 20px !important;
    height: 15px !important;
    object-fit: cover !important;
    border-radius: 2px !important;
}
.leadwa-flag-emoji {
    font-size: 14px !important;
    line-height: 1 !important;
}
.leadwa-dial-prefix {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace, sans-serif !important;
    font-size: 13px !important;
    font-weight: 700 !important;
    color: #0f172a !important;
}
.leadwa-picker-arrow {
    font-size: 10px !important;
    color: #94a3b8 !important;
    margin-left: 2px !important;
    transition: transform 0.2s ease !important;
}
.leadwa-country-picker-btn.open .leadwa-picker-arrow {
    transform: rotate(180deg) !important;
}
.leadwa-country-dropdown {
    position: absolute !important;
    top: calc(100% + 4px) !important;
    left: 0 !important;
    z-index: 9999 !important;
    width: 320px !important;
    max-width: 90vw !important;
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 8px !important;
    box-shadow: 0 10px 25px rgba(15, 23, 42, 0.18) !important;
    flex-direction: column !important;
    overflow: hidden !important;
    box-sizing: border-box !important;
}
.leadwa-country-search-wrap {
    padding: 8px 10px !important;
    border-bottom: 1px solid #f1f5f9 !important;
    background: #f8fafc !important;
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
}
.leadwa-country-search-wrap input {
    width: 100% !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 6px !important;
    padding: 6px 10px !important;
    font-size: 12px !important;
    outline: none !important;
    background: #ffffff !important;
    color: #0f172a !important;
    height: 32px !important;
    box-sizing: border-box !important;
}
.leadwa-country-search-wrap input:focus {
    border-color: #10b981 !important;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.15) !important;
}
.leadwa-country-list {
    max-height: 240px !important;
    overflow-y: auto !important;
    margin: 0 !important;
    padding: 4px 0 !important;
    list-style: none !important;
}
.leadwa-country-section-header {
    padding: 6px 12px 2px 12px !important;
    font-size: 10px !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.6px !important;
    color: #94a3b8 !important;
    background: #ffffff !important;
}
.leadwa-country-item {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 8px 12px !important;
    cursor: pointer !important;
    font-size: 13px !important;
    color: #334155 !important;
    transition: background 0.1s ease !important;
    user-select: none !important;
}
.leadwa-country-item:hover,
.leadwa-country-item.active {
    background: #f0fdf4 !important;
    color: #065f46 !important;
}
.leadwa-country-item-left {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    white-space: nowrap !important;
    flex: 1 1 auto !important;
}
.leadwa-country-item-name {
    font-weight: 500 !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    white-space: nowrap !important;
}
.leadwa-country-item-code {
    font-size: 12px !important;
    color: #059669 !important;
    font-weight: 600 !important;
    font-family: monospace !important;
    background: #dcfce7 !important;
    padding: 2px 6px !important;
    border-radius: 4px !important;
    margin-left: 8px !important;
    flex-shrink: 0 !important;
}
.leadwa-phone-input {
    flex: 1 1 auto !important;
    min-width: 120px !important;
    width: auto !important;
    border: none !important;
    outline: none !important;
    padding: 10px 14px !important;
    font-size: 15px !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace, sans-serif !important;
    color: #0f172a !important;
    background: transparent !important;
    box-shadow: none !important;
    height: auto !important;
    margin: 0 !important;
    line-height: 1.4 !important;
    box-sizing: border-box !important;
}
.leadwa-phone-input::placeholder {
    color: #94a3b8 !important;
    font-size: 13px !important;
}
.leadwa-phone-btn {
    border: none !important;
    background: #f8fafc !important;
    border-left: 1px solid #e2e8f0 !important;
    color: #334155 !important;
    padding: 0 16px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: background 0.15s, color 0.15s !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 6px !important;
    white-space: nowrap !important;
    user-select: none !important;
    outline: none !important;
    margin: 0 !important;
    height: auto !important;
    box-sizing: border-box !important;
    flex-shrink: 0 !important;
}
.leadwa-phone-btn:hover {
    background: #f1f5f9 !important;
    color: #0f172a !important;
}
.leadwa-phone-btn:disabled {
    opacity: 0.65 !important;
    cursor: not-allowed !important;
}
.leadwa-btn-clear {
    padding: 0 12px !important;
    color: #94a3b8 !important;
}
.leadwa-btn-clear:hover {
    color: #ef4444 !important;
}
.leadwa-country-chips {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
    margin-top: 8px !important;
    align-items: center !important;
}
.leadwa-country-chip {
    display: inline-flex !important;
    align-items: center !important;
    gap: 5px !important;
    padding: 3px 9px !important;
    border-radius: 14px !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    background: #f1f5f9 !important;
    color: #475569 !important;
    border: 1px solid #e2e8f0 !important;
    cursor: pointer !important;
    transition: all 0.15s ease !important;
    user-select: none !important;
    line-height: 1.3 !important;
}
.leadwa-country-chip:hover {
    background: #d1fae5 !important;
    color: #065f46 !important;
    border-color: #a7f3d0 !important;
    transform: translateY(-1px) !important;
}
.leadwa-chip-flag {
    display: inline-flex !important;
    align-items: center !important;
    width: 16px !important;
    height: 12px !important;
    overflow: hidden !important;
    border-radius: 1px !important;
    flex-shrink: 0 !important;
}
.leadwa-chip-flag img {
    display: block !important;
    width: 16px !important;
    height: 12px !important;
    object-fit: cover !important;
}
.leadwa-client-card-info {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 8px;
    padding: 12px 16px;
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}
.leadwa-preset-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-bottom: 8px;
}
.leadwa-preset-chip {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1d4ed8;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.leadwa-preset-chip:hover {
    background: #dbeafe;
    border-color: #93c5fd;
    transform: scale(1.02);
}
@media (max-width: 640px) {
    .leadwa-verify-text {
        display: none !important;
    }
    .leadwa-phone-btn.leadwa-btn-verify {
        padding: 0 12px !important;
    }
}
</style>

<div class="leadwa-container">
    <!-- Header -->
    <div class="leadwa-header">
        <div>
            <h1>
                <i class="fab fa-whatsapp"></i> LeadWhatsApp WHMCS Suite
            </h1>
            <p>Automated WhatsApp notifications, billing alerts, support ticket updates & 2FA verification for WHMCS</p>
        </div>
        <div class="leadwa-badge">
            <i class="fas fa-code-branch"></i> v1.2.1 &bull; LeadWhatsApp API
        </div>
    </div>

    <!-- Flash Notifications -->
    <?php if (!empty($flashMessage)): ?>
        <div class="alert alert-<?= htmlspecialchars($flashType) ?> alert-dismissible" role="alert" style="border-radius: 8px;">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <i class="fas <?= $flashType === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i>
            <?= htmlspecialchars($flashMessage) ?>
        </div>
    <?php endif; ?>

    <!-- Navigation Tabs -->
    <div class="leadwa-nav">
        <a href="<?= $moduleLink ?>&tab=dashboard" class="leadwa-nav-item <?= $tab === 'dashboard' ? 'active' : '' ?>">
            <i class="fas fa-chart-line"></i> Dashboard
        </a>
        <a href="<?= $moduleLink ?>&tab=templates" class="leadwa-nav-item <?= $tab === 'templates' ? 'active' : '' ?>">
            <i class="fas fa-comment-alt"></i> Notification Templates
        </a>
        <a href="<?= $moduleLink ?>&tab=logs" class="leadwa-nav-item <?= $tab === 'logs' ? 'active' : '' ?>">
            <i class="fas fa-list-alt"></i> Message Logs
        </a>
        <a href="<?= $moduleLink ?>&tab=send_test" class="leadwa-nav-item <?= $tab === 'send_test' ? 'active' : '' ?>">
            <i class="fas fa-paper-plane"></i> Quick / Test Sender
        </a>
        <a href="configaddonmods.php#leadwhatsapp" target="_blank" class="leadwa-nav-item">
            <i class="fas fa-cog"></i> Module Settings <i class="fas fa-external-link-alt" style="font-size: 10px;"></i>
        </a>
    </div>

    <!-- Active Tab Content -->
    <?php
    switch ($tab) {
        case 'templates':
            include __DIR__ . '/templates.php';
            break;
        case 'logs':
            include __DIR__ . '/logs.php';
            break;
        case 'send_test':
            include __DIR__ . '/send_test.php';
            break;
        case 'dashboard':
        default:
            include __DIR__ . '/dashboard.php';
            break;
    }
    ?>
</div>
