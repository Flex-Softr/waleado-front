<?php
/**
 * LeadWhatsApp WHMCS Module Template Manager
 */
$categories = [];
foreach ($templates as $tpl) {
    $categories[$tpl->category][] = $tpl;
}
?>

<div class="alert alert-info" style="border-radius: 8px; font-size: 13px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
    <div>
        <i class="fas fa-info-circle"></i>
        <strong>Template Tips:</strong> Use the toggle switches on each template to instantly enable or disable notifications. Click any <span class="leadwa-tag">{tag}</span> to insert it into the message editor. Standard WhatsApp formatting (<code>*bold*</code>, <code>_italic_</code>) is fully supported.
    </div>
    <div style="font-size: 12px; color: #0369a1;">
        <i class="fas fa-toggle-on text-success"></i> Toggle switches update status instantly
    </div>
</div>

<!-- Global Toast Notification Container -->
<div id="leadwaToast" class="leadwa-toast">
    <i class="fas fa-check-circle"></i>
    <span id="leadwaToastMsg">Status updated</span>
</div>

<?php foreach ($categories as $categoryName => $catTemplates): 
    $catId = preg_replace('/[^a-zA-Z0-9]/', '_', strtolower($categoryName));
    $activeCount = count(array_filter($catTemplates, fn($t) => (bool)$t->is_active));
?>
    <div class="leadwa-card">
        <div class="leadwa-card-header" style="background: #f8fafc;">
            <h3>
                <i class="fas fa-folder-open text-primary"></i> <?= htmlspecialchars($categoryName) ?> Notifications
            </h3>
            <span class="badge badge-info" id="cat_badge_<?= $catId ?>">
                <span class="active-count"><?= $activeCount ?></span> / <?= count($catTemplates) ?> Active
            </span>
        </div>
        <div class="leadwa-card-body" style="padding: 0;">
            <?php foreach ($catTemplates as $index => $tpl): ?>
                <div id="tpl_row_<?= $tpl->id ?>" class="leadwa-template-row <?= !$tpl->is_active ? 'disabled-template' : '' ?>" style="border-bottom: <?= $index === count($catTemplates) - 1 ? 'none' : '1px solid #e2e8f0' ?>;">
                    <form method="POST" action="<?= $moduleLink ?>" id="tpl_form_<?= $tpl->id ?>">
                        <input type="hidden" name="action" value="save_template">
                        <input type="hidden" name="template_id" value="<?= $tpl->id ?>">
                        <input type="hidden" name="is_active" id="tpl_is_active_input_<?= $tpl->id ?>" value="<?= $tpl->is_active ? '1' : '0' ?>">

                        <div class="row">
                            <div class="col-md-7">
                                <!-- Template Header: Title, Tags & Quick Toggle Switch -->
                                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 10px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: #0f172a;">
                                            <?= htmlspecialchars($tpl->name) ?>
                                        </h4>
                                        <?php if ($tpl->send_to_admin): ?>
                                            <span class="label label-warning" title="Dispatches directly to Admin WhatsApp number"><i class="fas fa-shield-alt"></i> Admin Alert</span>
                                        <?php else: ?>
                                            <span class="label label-success"><i class="fas fa-user"></i> Client Alert</span>
                                        <?php endif; ?>
                                        <?php if ($tpl->category === 'Invoice' || strpos($tpl->event_key, 'invoice_') === 0 || $tpl->event_key === 'service_order_accepted'): ?>
                                            <span class="label label-info" title="Generated WHMCS PDF Invoice is automatically attached to this WhatsApp message"><i class="fas fa-file-pdf"></i> PDF Invoice Attached</span>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Quick Toggle Switch Button -->
                                    <div style="display: flex; align-items: center; gap: 10px; background: #ffffff; padding: 4px 10px; border-radius: 20px; border: 1px solid #e2e8f0;">
                                        <span id="tpl_badge_<?= $tpl->id ?>" class="leadwa-badge-status <?= $tpl->is_active ? 'active' : 'inactive' ?>">
                                            <i class="fas <?= $tpl->is_active ? 'fa-check-circle' : 'fa-pause-circle' ?>"></i>
                                            <span class="status-text"><?= $tpl->is_active ? 'Active' : 'Disabled' ?></span>
                                        </span>

                                        <label class="leadwa-switch" title="Toggle to enable/disable template">
                                            <input type="checkbox" id="tpl_toggle_<?= $tpl->id ?>" onchange="toggleTemplate(<?= $tpl->id ?>, this.checked, '<?= htmlspecialchars(addslashes($tpl->name)) ?>', '<?= $catId ?>')" <?= $tpl->is_active ? 'checked' : '' ?>>
                                            <span class="leadwa-slider"></span>
                                        </label>
                                    </div>
                                </div>

                                <p style="font-size: 12px; color: #64748b; margin-bottom: 12px;">
                                    <?= htmlspecialchars($tpl->description) ?> &bull; <code><?= htmlspecialchars($tpl->event_key) ?></code>
                                </p>

                                <div class="form-group" style="margin-bottom: 12px;">
                                    <textarea name="template_text" id="tpl_text_<?= $tpl->id ?>" class="form-control" rows="5" style="font-family: monospace; font-size: 13px; resize: vertical; border-radius: 6px;"><?= htmlspecialchars($tpl->template_text) ?></textarea>
                                </div>

                                <div style="display: flex; gap: 16px; align-items: center; justify-content: space-between; flex-wrap: wrap;">
                                    <label style="font-weight: 600; font-size: 13px; cursor: pointer; margin: 0; display: flex; align-items: center; gap: 6px;">
                                        <input type="checkbox" name="send_to_admin" value="1" <?= $tpl->send_to_admin ? 'checked' : '' ?>>
                                        Route to Admin WhatsApp Number
                                    </label>
                                    <button type="submit" class="btn btn-sm btn-primary" style="background: #10b981; border-color: #059669; font-weight: 600;">
                                        <i class="fas fa-save"></i> Save Template Text
                                    </button>
                                </div>
                            </div>

                            <div class="col-md-5" style="background: #fafafa; border-radius: 8px; padding: 14px 16px; border: 1px dashed #cbd5e1;">
                                <h5 style="margin: 0 0 8px 0; font-size: 12px; text-transform: uppercase; font-weight: 700; color: #475569;">
                                    <i class="fas fa-tags text-muted"></i> Available Merge Tags
                                </h5>
                                <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                    <?php
                                    $tags = array_filter(array_map('trim', explode(',', $tpl->variables . ',{company_name},{system_url},{clientarea_url},{current_date},{current_time}')));
                                    foreach (array_unique($tags) as $tag):
                                    ?>
                                        <span class="leadwa-tag" onclick="insertTag('tpl_text_<?= $tpl->id ?>', '<?= htmlspecialchars($tag) ?>')"><?= htmlspecialchars($tag) ?></span>
                                    <?php endforeach; ?>
                                </div>
                                <div style="margin-top: 10px; font-size: 11px; color: #94a3b8;">
                                    Click any tag above to insert it at your cursor position in the editor.
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>

<script>
function insertTag(textareaId, tag) {
    const el = document.getElementById(textareaId);
    if (!el) return;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const text = el.value;
    el.value = text.substring(0, start) + tag + text.substring(end);
    el.selectionStart = el.selectionEnd = start + tag.length;
    el.focus();
}

function showToast(message, isSuccess = true) {
    const toast = document.getElementById('leadwaToast');
    const toastMsg = document.getElementById('leadwaToastMsg');
    if (!toast || !toastMsg) return;

    toast.className = 'leadwa-toast ' + (isSuccess ? 'success' : 'error') + ' show';
    toastMsg.textContent = message;

    setTimeout(() => {
        toast.className = 'leadwa-toast';
    }, 3000);
}

function toggleTemplate(templateId, isChecked, templateName, catId) {
    const row = document.getElementById('tpl_row_' + templateId);
    const badge = document.getElementById('tpl_badge_' + templateId);
    const hiddenInput = document.getElementById('tpl_is_active_input_' + templateId);

    // Sync hidden input
    if (hiddenInput) {
        hiddenInput.value = isChecked ? '1' : '0';
    }

    // Immediate UI feedback
    if (isChecked) {
        if (row) row.classList.remove('disabled-template');
        if (badge) {
            badge.className = 'leadwa-badge-status active';
            badge.innerHTML = '<i class="fas fa-check-circle"></i> <span class="status-text">Active</span>';
        }
    } else {
        if (row) row.classList.add('disabled-template');
        if (badge) {
            badge.className = 'leadwa-badge-status inactive';
            badge.innerHTML = '<i class="fas fa-pause-circle"></i> <span class="status-text">Disabled</span>';
        }
    }

    // Update category active counter
    const catBadge = document.getElementById('cat_badge_' + catId);
    if (catBadge) {
        const countSpan = catBadge.querySelector('.active-count');
        if (countSpan) {
            let current = parseInt(countSpan.textContent, 10) || 0;
            current = isChecked ? current + 1 : Math.max(0, current - 1);
            countSpan.textContent = current;
        }
    }

    // Asynchronous backend update
    const formData = new FormData();
    formData.append('action', 'toggle_template');
    formData.append('template_id', templateId);
    formData.append('is_active', isChecked ? '1' : '0');
    formData.append('ajax', '1');

    fetch('<?= $moduleLink ?>', {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast(data.message || (isChecked ? `Template '${templateName}' enabled.` : `Template '${templateName}' disabled.`), true);
        } else {
            showToast(data.message || 'Failed to update template status.', false);
        }
    })
    .catch(err => {
        console.error('Toggle error:', err);
        showToast('Status updated locally.', true);
    });
}
</script>
