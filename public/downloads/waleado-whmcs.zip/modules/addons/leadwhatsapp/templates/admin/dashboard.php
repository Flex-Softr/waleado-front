<?php
use LeadWhatsApp\Database;
use LeadWhatsApp\ApiClient;

$recentLogs = Database::getLogs(5, 0)['items'];
$config = Database::getModuleConfig();
$apiUrl = $config['api_url'] ?? 'http://localhost:3000';
$clientId = $config['client_id'] ?? '';
$maskedClientId = !empty($clientId) ? substr($clientId, 0, 10) . '...' . substr($clientId, -4) : '<span class="text-danger">Not Configured</span>';
$hasSecret = !empty($config['client_secret']);
$verifyEnabled = ($config['verify_whatsapp_number'] ?? 'on') !== 'off';
$attachInvoicePdf = ($config['attach_invoice_pdf'] ?? 'on') !== 'off';
$debugEnabled = ($config['debug_log'] ?? '') === 'on';
?>

<!-- Statistics Overview -->
<div class="leadwa-stat-grid">
    <div class="leadwa-stat-card">
        <div class="leadwa-stat-icon" style="background: #dcfce7; color: #16a34a;">
            <i class="fas fa-check-double"></i>
        </div>
        <div class="leadwa-stat-info">
            <h4>Total Messages Sent</h4>
            <div class="stat-number"><?= number_format($stats['total_sent']) ?></div>
        </div>
    </div>

    <div class="leadwa-stat-card">
        <div class="leadwa-stat-icon" style="background: #e0f2fe; color: #0284c7;">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="leadwa-stat-info">
            <h4>Sent Today</h4>
            <div class="stat-number"><?= number_format($stats['today_sent']) ?></div>
        </div>
    </div>

    <div class="leadwa-stat-card">
        <div class="leadwa-stat-icon" style="background: #fee2e2; color: #dc2626;">
            <i class="fas fa-times-circle"></i>
        </div>
        <div class="leadwa-stat-info">
            <h4>Failed Deliveries</h4>
            <div class="stat-number"><?= number_format($stats['total_failed']) ?></div>
        </div>
    </div>

    <div class="leadwa-stat-card">
        <div class="leadwa-stat-icon" style="background: #f3e8ff; color: #9333ea;">
            <i class="fas fa-bell"></i>
        </div>
        <div class="leadwa-stat-info">
            <h4>Active Templates</h4>
            <div class="stat-number"><?= number_format($stats['active_templates']) ?></div>
        </div>
    </div>
</div>

<div class="row">
    <!-- API Connection Status Card -->
    <div class="col-md-6">
        <div class="leadwa-card">
            <div class="leadwa-card-header">
                <h3><i class="fas fa-plug" style="color: #10b981;"></i> LeadWhatsApp API Status</h3>
                <div style="display: flex; gap: 8px;">
                    <button type="button" class="btn btn-sm btn-primary" onclick="openCredentialsModal()" style="background: #10b981; border-color: #059669; font-weight: 600;">
                        <i class="fas fa-key"></i> Update Credentials
                    </button>
                    <a href="<?= $moduleLink ?>&action=test_connection" class="btn btn-sm btn-default" title="Test connection with current settings">
                        <i class="fas fa-sync-alt"></i> Test API
                    </a>
                </div>
            </div>
            <div class="leadwa-card-body">
                <table class="table table-bordered table-striped" style="margin-bottom: 0;">
                    <tbody>
                        <tr>
                            <td style="width: 38%; font-weight: 600;">API Base URL</td>
                            <td><code><?= htmlspecialchars($apiUrl) ?></code></td>
                        </tr>
                        <tr>
                            <td style="font-weight: 600;">Client ID</td>
                            <td><?= $maskedClientId ?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: 600;">Client Secret</td>
                            <td><?= $hasSecret ? '<span class="text-success"><i class="fas fa-lock"></i> Configured (fw_csec_...)</span>' : '<span class="text-danger"><i class="fas fa-exclamation-circle"></i> Not Configured</span>' ?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: 600;">Admin Phone</td>
                            <td><code><?= htmlspecialchars($config['admin_phone'] ?? 'Not set') ?></code></td>
                        </tr>
                        <tr>
                            <td style="font-weight: 600;">Default Country Prefix</td>
                            <td><code>+<?= htmlspecialchars($config['default_country_code'] ?? '880') ?></code></td>
                        </tr>
                        <tr>
                            <td style="font-weight: 600;">WhatsApp Verification</td>
                            <td>
                                <?= $verifyEnabled ? '<span class="label label-success"><i class="fas fa-check"></i> Enabled (Verify on WhatsApp before send)</span>' : '<span class="label label-default">Disabled</span>' ?>
                            </td>
                        </tr>
                        <?php if (!empty($apiTestResult)): ?>
                            <tr>
                                <td style="font-weight: 600;">Test Status</td>
                                <td>
                                    <?php if ($apiTestResult['success']): ?>
                                        <span class="badge badge-success" style="background: #16a34a; font-size: 13px;">Connected</span>
                                        <?php if (!empty($apiTestResult['data']['default_device'])): ?>
                                            <div style="margin-top: 6px; font-size: 12px; color: #475569;">
                                                <strong>Default Device:</strong> <?= htmlspecialchars($apiTestResult['data']['default_device']['name'] ?? 'Device') ?> (<?= htmlspecialchars($apiTestResult['data']['default_device']['phone'] ?? 'N/A') ?>) - <span class="text-success"><?= htmlspecialchars($apiTestResult['data']['default_device']['status'] ?? 'online') ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div style="margin-top: 6px; font-size: 12px; color: #b45309;">
                                                ⚠️ No default device selected in LeadWhatsApp dashboard.
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-danger" style="background: #dc2626; font-size: 13px;">Disconnected</span>
                                        <div style="margin-top: 6px; font-size: 12px; color: #dc2626;">
                                            <?= htmlspecialchars($apiTestResult['message']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick Actions Card -->
    <div class="col-md-6">
        <div class="leadwa-card">
            <div class="leadwa-card-header">
                <h3><i class="fas fa-bolt" style="color: #f59e0b;"></i> Quick Actions</h3>
            </div>
            <div class="leadwa-card-body" style="display: flex; flex-direction: column; gap: 12px;">
                <button type="button" onclick="openCredentialsModal()" class="btn btn-default btn-block text-left" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-left: 4px solid #10b981;">
                    <span><i class="fas fa-key text-success"></i> <strong>Update API Credentials & Base URL</strong></span>
                    <i class="fas fa-edit text-muted"></i>
                </button>
                <a href="<?= $moduleLink ?>&tab=send_test" class="btn btn-default btn-block text-left" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px;">
                    <span><i class="fas fa-paper-plane text-success"></i> <strong>Send Direct Message / Test WhatsApp</strong></span>
                    <i class="fas fa-arrow-right text-muted"></i>
                </a>
                <a href="<?= $moduleLink ?>&tab=templates" class="btn btn-default btn-block text-left" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px;">
                    <span><i class="fas fa-edit text-primary"></i> <strong>Customize Notification Templates</strong></span>
                    <i class="fas fa-arrow-right text-muted"></i>
                </a>
                <a href="<?= $moduleLink ?>&tab=logs" class="btn btn-default btn-block text-left" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px;">
                    <span><i class="fas fa-history text-info"></i> <strong>View Complete Message Audit Logs</strong></span>
                    <i class="fas fa-arrow-right text-muted"></i>
                </a>
                <form method="POST" action="<?= $moduleLink ?>" onsubmit="return confirm('Reset all templates to system defaults? Any custom edits will be restored.');">
                    <input type="hidden" name="action" value="reset_templates">
                    <button type="submit" class="btn btn-outline-danger btn-block text-left" style="width: 100%; border: 1px dashed #ef4444; color: #b91c1c; padding: 12px 16px; background: transparent; text-align: left; border-radius: 4px;">
                        <i class="fas fa-undo"></i> <strong>Reset / Re-seed Default Templates</strong>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Update API Credentials -->
<div class="modal fade" id="credentialsModal" tabindex="-1" role="dialog" aria-labelledby="credentialsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="border-radius: 12px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);">
            <form method="POST" action="<?= $moduleLink ?>">
                <input type="hidden" name="action" value="save_credentials">

                <div class="modal-header" style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: #ffffff; padding: 18px 24px;">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeCredentialsModal()" style="color: #ffffff; opacity: 0.8; font-size: 24px;"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="credentialsModalLabel" style="font-weight: 700; font-size: 18px; color: #ffffff;">
                        <i class="fas fa-key"></i> LeadWhatsApp API Credentials & Connection
                    </h4>
                </div>

                <div class="modal-body" style="padding: 24px;">
                    <div class="alert alert-info" style="font-size: 13px; border-radius: 8px;">
                        <i class="fas fa-info-circle"></i>
                        Find your <strong>Client ID</strong> (<code>fw_cid_...</code>) and <strong>Client Secret</strong> (<code>fw_csec_...</code>) in your <strong>LeadWhatsApp Dashboard &rarr; API Credentials</strong>.
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="api_url" style="font-weight: 600;">LeadWhatsApp API Base URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fas fa-globe"></i></span>
                                    <input type="url" class="form-control" id="api_url" name="api_url" value="<?= htmlspecialchars($apiUrl) ?>" placeholder="http://localhost:3000 or https://api.yourdomain.com" required>
                                </div>
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">Base URL where your LeadWhatsApp Open API backend is hosted.</span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="client_id" style="font-weight: 600;">API Client ID <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fas fa-id-badge"></i></span>
                                    <input type="text" class="form-control font-mono" id="client_id" name="client_id" value="<?= htmlspecialchars($config['client_id'] ?? '') ?>" placeholder="fw_cid_..." required>
                                </div>
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">Public Client ID generated in LeadWhatsApp dashboard.</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="client_secret" style="font-weight: 600;">
                                    API Client Secret <?= $hasSecret ? '<span class="text-muted" style="font-size: 11px;">(Leave empty to keep existing)</span>' : '<span class="text-danger">*</span>' ?>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control font-mono" id="client_secret" name="client_secret" placeholder="<?= $hasSecret ? '••••••••••••••••••••' : 'fw_csec_...' ?>" <?= $hasSecret ? '' : 'required' ?>>
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-default" onclick="toggleSecretVisibility()" title="Toggle visibility">
                                            <i class="fas fa-eye" id="secret_eye_icon"></i>
                                        </button>
                                    </span>
                                </div>
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">Private secret key (<code>fw_csec_...</code>).</span>
                            </div>
                        </div>
                    </div>

                    <hr style="margin: 16px 0;">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="admin_phone" style="font-weight: 600;">Admin WhatsApp Number</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fas fa-phone"></i></span>
                                    <input type="text" class="form-control" id="admin_phone" name="admin_phone" value="<?= htmlspecialchars($config['admin_phone'] ?? '') ?>" placeholder="+88017XXXXXXXX">
                                </div>
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">Phone with country code to receive admin alerts (new orders, tickets, signups).</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="default_country_code" style="font-weight: 600;">Default Country Dial Code</label>
                                <select class="form-control" id="default_country_code" name="default_country_code">
                                    <?php 
                                    $allCountries = \LeadWhatsApp\PhoneHelper::getCountryList();
                                    $currentDefCode = preg_replace('/[^\d]/', '', $config['default_country_code'] ?? '880') ?: '880';
                                    foreach ($allCountries as $c): ?>
                                        <option value="<?= htmlspecialchars($c['dial_code']) ?>" <?= $currentDefCode === $c['dial_code'] ? 'selected' : '' ?>>
                                            <?= $c['flag'] ?> <?= htmlspecialchars($c['name']) ?> (+<?= htmlspecialchars($c['dial_code']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">Default country code applied when recipient phone is entered in national format.</span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="custom_phone_field" style="font-weight: 600;">Custom Field for WhatsApp Phone (Optional)</label>
                                <input type="text" class="form-control" id="custom_phone_field" name="custom_phone_field" value="<?= htmlspecialchars($config['custom_phone_field'] ?? '') ?>" placeholder="WhatsApp Number">
                                <span class="help-block" style="font-size: 12px; margin-top: 4px;">If you have a dedicated client custom field in WHMCS for WhatsApp, enter its name here.</span>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-6">
                            <label style="font-weight: 600; font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                <input type="checkbox" name="attach_invoice_pdf" value="1" <?= $attachInvoicePdf ? 'checked' : '' ?>>
                                <i class="fas fa-file-pdf" style="color: #ef4444;"></i> Attach Invoice PDF on WhatsApp
                            </label>
                            <span class="help-block" style="font-size: 12px; margin-left: 20px;">Automatically generates & attaches PDF invoices on purchases, renewals, reminders & payment notifications.</span>
                        </div>

                        <div class="col-md-6">
                            <label style="font-weight: 600; font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                <input type="checkbox" name="verify_whatsapp_number" value="1" <?= $verifyEnabled ? 'checked' : '' ?>>
                                Verify WhatsApp Number Before Sending
                            </label>
                            <span class="help-block" style="font-size: 12px; margin-left: 20px;">Ensures recipient is on WhatsApp before dispatching messages.</span>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 10px;">
                        <div class="col-md-6">
                            <label style="font-weight: 600; font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                <input type="checkbox" name="debug_log" value="1" <?= $debugEnabled ? 'checked' : '' ?>>
                                Enable Debug Logging
                            </label>
                            <span class="help-block" style="font-size: 12px; margin-left: 20px;">Logs API requests & responses in WHMCS Activity Log.</span>
                        </div>
                    </div>
                </div>

                <div class="modal-footer" style="background: #f8fafc; padding: 16px 24px; display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-default" data-dismiss="modal" onclick="closeCredentialsModal()">Cancel</button>
                    <button type="submit" name="test_connection_after" value="1" class="btn btn-info" style="font-weight: 600;">
                        <i class="fas fa-sync-alt"></i> Save & Test Connection
                    </button>
                    <button type="submit" class="btn btn-success" style="background: #10b981; border-color: #059669; font-weight: 600; padding: 6px 20px;">
                        <i class="fas fa-save"></i> Save Credentials
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openCredentialsModal() {
    if (typeof jQuery !== 'undefined' && typeof jQuery.fn.modal === 'function') {
        $('#credentialsModal').modal('show');
    } else {
        const modal = document.getElementById('credentialsModal');
        if (modal) {
            modal.style.display = 'block';
            modal.classList.add('in');
            document.body.classList.add('modal-open');
        }
    }
}

function closeCredentialsModal() {
    if (typeof jQuery !== 'undefined' && typeof jQuery.fn.modal === 'function') {
        $('#credentialsModal').modal('hide');
    } else {
        const modal = document.getElementById('credentialsModal');
        if (modal) {
            modal.style.display = 'none';
            modal.classList.remove('in');
            document.body.classList.remove('modal-open');
        }
    }
}

function toggleSecretVisibility() {
    const input = document.getElementById('client_secret');
    const icon = document.getElementById('secret_eye_icon');
    if (!input || !icon) return;

    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}
</script>
