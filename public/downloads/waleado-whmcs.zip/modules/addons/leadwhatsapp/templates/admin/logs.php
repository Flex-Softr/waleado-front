<?php
use LeadWhatsApp\Database;

$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 25;
$offset = ($page - 1) * $limit;

$filters = [
    'search' => trim($_GET['search'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
];

$logData = Database::getLogs($limit, $offset, $filters);
$logs = $logData['items'];
$total = $logData['total'];
$totalPages = ceil($total / $limit);
?>

<div class="leadwa-card">
    <div class="leadwa-card-header">
        <h3><i class="fas fa-list-alt text-info"></i> WhatsApp Message Logs (<?= number_format($total) ?> Total)</h3>
    </div>
    <div class="leadwa-card-body">
        <!-- Search & Filter Bar -->
        <form method="GET" action="addonmodules.php" class="form-inline" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
            <input type="hidden" name="module" value="leadwhatsapp">
            <input type="hidden" name="tab" value="logs">

            <div class="form-group">
                <input type="text" name="search" class="form-control input-sm" placeholder="Search phone or text..." value="<?= htmlspecialchars($filters['search']) ?>" style="min-width: 220px;">
            </div>

            <div class="form-group">
                <select name="status" class="form-control input-sm">
                    <option value="">All Statuses</option>
                    <option value="sent" <?= $filters['status'] === 'sent' ? 'selected' : '' ?>>Sent</option>
                    <option value="failed" <?= $filters['status'] === 'failed' ? 'selected' : '' ?>>Failed</option>
                    <option value="pending" <?= $filters['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                </select>
            </div>

            <button type="submit" class="btn btn-sm btn-primary">
                <i class="fas fa-filter"></i> Filter
            </button>
            <?php if (!empty($filters['search']) || !empty($filters['status'])): ?>
                <a href="<?= $moduleLink ?>&tab=logs" class="btn btn-sm btn-default">Clear</a>
            <?php endif; ?>
        </form>

        <!-- Logs Table -->
        <?php if (empty($logs)): ?>
            <div style="padding: 40px; text-align: center; color: #64748b;">
                <i class="fas fa-search fa-3x" style="color: #cbd5e1; margin-bottom: 12px;"></i>
                <p>No message logs matched your query.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover table-bordered" style="margin-bottom: 0;">
                    <thead style="background: #f8fafc; font-size: 12px; text-transform: uppercase;">
                        <tr>
                            <th style="width: 60px;">ID</th>
                            <th>Phone</th>
                            <th>Event / Ref</th>
                            <th>Message Content</th>
                            <th>Status</th>
                            <th>Error / Response</th>
                            <th>Timestamp</th>
                            <th style="width: 90px; text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td>#<?= $log->id ?></td>
                                <td>
                                    <strong><code><?= htmlspecialchars($log->recipient_phone) ?></code></strong>
                                    <?php if ($log->client_id): ?>
                                        <div style="font-size: 11px;">
                                            <a href="clientssummary.php?userid=<?= $log->client_id ?>" target="_blank">Client #<?= $log->client_id ?></a>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="label label-default"><?= htmlspecialchars($log->event_key ?: 'Direct Send') ?></span>
                                    <?php if ($log->rel_type && $log->rel_id): ?>
                                        <div style="font-size: 11px; color: #64748b;">
                                            Ref: <?= htmlspecialchars($log->rel_type) ?> #<?= htmlspecialchars($log->rel_id) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td style="max-width: 300px; font-size: 12px;">
                                    <div style="max-height: 80px; overflow-y: auto; white-space: pre-wrap; font-family: monospace; background: #f8fafc; padding: 6px; border-radius: 4px; border: 1px solid #e2e8f0;"><?= htmlspecialchars($log->message_text) ?></div>
                                </td>
                                <td>
                                    <span class="leadwa-status-pill <?= $log->status ?>">
                                        <i class="fas <?= $log->status === 'sent' ? 'fa-check' : ($log->status === 'failed' ? 'fa-times' : 'fa-hourglass-half') ?>"></i>
                                        <?= ucfirst($log->status) ?>
                                    </span>
                                </td>
                                <td style="font-size: 11px; color: #dc2626; max-width: 180px;">
                                    <?= htmlspecialchars($log->error_message ?: ($log->status === 'sent' ? 'Delivered to Gateway' : '-')) ?>
                                </td>
                                <td style="font-size: 11px; color: #64748b; white-space: nowrap;">
                                    <?= $log->created_at ?>
                                </td>
                                <td style="text-align: center;">
                                    <form method="POST" action="<?= $moduleLink ?>" onsubmit="return confirm('Resend this message now?');">
                                        <input type="hidden" name="action" value="resend_log">
                                        <input type="hidden" name="log_id" value="<?= $log->id ?>">
                                        <button type="submit" class="btn btn-xs btn-default" title="Resend message">
                                            <i class="fas fa-redo"></i> Resend
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div style="font-size: 13px; color: #64748b;">
                        Showing <?= ($offset + 1) ?> to <?= min($total, $offset + $limit) ?> of <?= number_format($total) ?> entries
                    </div>
                    <ul class="pagination pagination-sm" style="margin: 0;">
                        <?php if ($page > 1): ?>
                            <li><a href="<?= $moduleLink ?>&tab=logs&page=<?= $page - 1 ?>&search=<?= urlencode($filters['search']) ?>&status=<?= urlencode($filters['status']) ?>">&laquo; Prev</a></li>
                        <?php endif; ?>

                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <li class="<?= $i === $page ? 'active' : '' ?>">
                                <a href="<?= $moduleLink ?>&tab=logs&page=<?= $i ?>&search=<?= urlencode($filters['search']) ?>&status=<?= urlencode($filters['status']) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $totalPages): ?>
                            <li><a href="<?= $moduleLink ?>&tab=logs&page=<?= $page + 1 ?>&search=<?= urlencode($filters['search']) ?>&status=<?= urlencode($filters['status']) ?>">Next &raquo;</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
