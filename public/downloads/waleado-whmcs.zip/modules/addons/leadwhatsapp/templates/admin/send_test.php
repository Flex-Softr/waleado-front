<?php
use LeadWhatsApp\PhoneHelper;
use LeadWhatsApp\Database;
use WHMCS\Database\Capsule;

$config = Database::getModuleConfig();
$allCountries = PhoneHelper::getCountryList();
$defaultCountryPrefix = preg_replace('/[^\d]/', '', $config['default_country_code'] ?? '880') ?: '880';

// Determine initial country from default country dial code
$initialCountry = null;
foreach ($allCountries as $c) {
    if ($c['dial_code'] === $defaultCountryPrefix) {
        $initialCountry = $c;
        break;
    }
}
if (!$initialCountry) {
    $initialCountry = $allCountries[0] ?? ['code' => 'BD', 'name' => 'Bangladesh', 'dial_code' => '880', 'flag' => '🇧🇩', 'popular' => true];
}

$prefillClientId = (int)($_GET['client_id'] ?? 0);
$prefillPhone = '';

if ($prefillClientId > 0) {
    $prefillPhone = PhoneHelper::getClientPhone($prefillClientId) ?? '';
}

// Fetch recent active clients for the selector
$clients = [];
try {
    $clients = Capsule::table('tblclients')
        ->select(['id', 'firstname', 'lastname', 'companyname', 'email', 'phonenumber', 'country'])
        ->orderBy('id', 'desc')
        ->take(150)
        ->get();
} catch (\Throwable $e) {
    try {
        $clients = Capsule::table('tblclients')->orderBy('id', 'desc')->take(150)->get();
    } catch (\Throwable $e2) {
        $clients = [];
    }
}
?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="leadwa-card">
            <div class="leadwa-card-header" style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                <div>
                    <h3 style="margin: 0; color: #0f172a; font-size: 17px; font-weight: 700;">
                        <i class="fas fa-paper-plane text-success"></i> Direct WhatsApp Message / Test Sender
                    </h3>
                    <p style="color: #64748b; font-size: 12px; margin: 4px 0 0 0;">
                        Send an immediate WhatsApp message to any phone number or existing WHMCS client via LeadWhatsApp API.
                    </p>
                </div>
                <span class="leadwa-badge-status active" style="font-size: 11px;">
                    <i class="fas fa-bolt"></i> v1.2.1 Ready
                </span>
            </div>
            <div class="leadwa-card-body">

                <!-- Mode Selector Tabs -->
                <div class="leadwa-mode-tabs">
                    <button type="button" id="tab_mode_manual" class="leadwa-mode-tab <?= $prefillClientId > 0 ? '' : 'active' ?>" onclick="setSenderMode('manual')">
                        <i class="fas fa-keyboard"></i> Enter Number Manually
                    </button>
                    <button type="button" id="tab_mode_client" class="leadwa-mode-tab <?= $prefillClientId > 0 ? 'active' : '' ?>" onclick="setSenderMode('client')">
                        <i class="fas fa-user-check"></i> Select WHMCS Client (<?= count($clients) ?>)
                    </button>
                </div>

                <form method="POST" action="<?= $moduleLink ?>" id="leadwa_send_form" onsubmit="return handleFormSubmit(this)">
                    <input type="hidden" name="action" value="send_direct">
                    <input type="hidden" name="client_id" id="hidden_client_id" value="<?= $prefillClientId > 0 ? $prefillClientId : '' ?>">

                    <!-- Client Selector (Visible when Client Mode is active) -->
                    <div id="client_select_wrapper" class="form-group" style="display: <?= $prefillClientId > 0 ? 'block' : 'none' ?>; margin-bottom: 20px;">
                        <label for="client_select" style="font-weight: 600; color: #334155; font-size: 13px;">
                            <i class="fas fa-users text-primary"></i> Select WHMCS Client
                        </label>
                        <select id="client_select" class="form-control" style="width: 100%; font-size: 14px; height: 38px;">
                            <option value="" data-phone="" data-name="" data-email="" data-company="" data-country="">-- Choose Client to Autofill Phone --</option>
                            <?php foreach ($clients as $c): 
                                $clientId = (int)($c->id ?? 0);
                                $firstName = trim((string)($c->firstname ?? ''));
                                $lastName = trim((string)($c->lastname ?? ''));
                                $fullName = trim("{$firstName} {$lastName}");
                                $company = trim((string)($c->companyname ?? ''));
                                $email = trim((string)($c->email ?? ''));
                                $clientCountry = trim((string)($c->country ?? ''));

                                $displayName = !empty($fullName) ? $fullName : (!empty($company) ? $company : "Client #{$clientId}");
                                if (!empty($company) && !empty($fullName)) {
                                    $displayName .= " ({$company})";
                                }

                                $resolvedPhone = PhoneHelper::getClientPhone($clientId);
                                $rawPhone = trim((string)($c->phonenumber ?? ''));
                                $phoneAttr = $resolvedPhone ?: $rawPhone;
                                $phoneDisplay = $resolvedPhone ?: (!empty($rawPhone) ? $rawPhone : 'No Phone');
                            ?>
                                <option value="<?= $clientId ?>" 
                                        data-phone="<?= htmlspecialchars((string)$phoneAttr) ?>" 
                                        data-name="<?= htmlspecialchars($displayName) ?>"
                                        data-email="<?= htmlspecialchars($email) ?>"
                                        data-company="<?= htmlspecialchars($company) ?>"
                                        data-country="<?= htmlspecialchars($clientCountry) ?>"
                                        <?= $prefillClientId === $clientId ? 'selected' : '' ?>>
                                    #<?= $clientId ?> - <?= htmlspecialchars($displayName) ?> [<?= htmlspecialchars($phoneDisplay) ?>]
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <!-- Selected Client Badge Details -->
                        <div id="selected_client_card" class="leadwa-client-card-info" style="display: none;">
                            <div>
                                <div style="font-weight: 700; color: #065f46; font-size: 13px;">
                                    <i class="fas fa-user-circle"></i> <span id="card_client_name">Client Name</span>
                                    <span id="card_client_id" class="badge" style="background: #059669; margin-left: 6px;">#0</span>
                                </div>
                                <div style="font-size: 12px; color: #047857; margin-top: 3px;">
                                    <i class="fas fa-envelope"></i> <span id="card_client_email">email@example.com</span> &bull; 
                                    <i class="fas fa-phone"></i> <span id="card_client_phone">No Phone</span>
                                </div>
                            </div>
                            <button type="button" class="btn btn-xs btn-default" onclick="clearSelectedClient()" style="color: #b91c1c;">
                                <i class="fas fa-times"></i> Deselect Client
                            </button>
                        </div>
                    </div>

                    <!-- Recipient Phone Input with Integrated Country Selector -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label for="recipient_phone" style="font-weight: 600; color: #334155; font-size: 13px; display: flex; justify-content: space-between; align-items: center;">
                            <span>Recipient Phone Number <span class="text-danger">*</span></span>
                            <span id="phone_mode_indicator" class="text-muted" style="font-size: 11px; font-weight: normal;">Manual Mode</span>
                        </label>

                        <!-- Fully Isolated Input Group with Country Dropdown -->
                        <div class="leadwa-phone-group" id="leadwa_phone_group_container">
                            
                            <!-- Searchable Country Dropdown Trigger -->
                            <div class="leadwa-country-picker-wrap" id="leadwa_picker_wrap">
                                <button type="button" class="leadwa-country-picker-btn" id="leadwa_country_btn" onclick="toggleCountryDropdown(event)" title="Select Country Code">
                                    <span class="leadwa-flag-icon" id="selected_country_flag">
                                        <img src="https://flagcdn.com/20x15/<?= strtolower($initialCountry['code']) ?>.png" 
                                             srcset="https://flagcdn.com/40x30/<?= strtolower($initialCountry['code']) ?>.png 2x" 
                                             width="20" height="15" 
                                             alt="<?= htmlspecialchars($initialCountry['code']) ?>" 
                                             onerror="this.style.display='none';this.nextElementSibling.style.display='inline-block';">
                                        <span class="leadwa-flag-emoji" style="display:none;"><?= $initialCountry['flag'] ?></span>
                                    </span>
                                    <span class="leadwa-dial-prefix" id="selected_dial_prefix">+<?= htmlspecialchars($initialCountry['dial_code']) ?></span>
                                    <i class="fas fa-chevron-down leadwa-picker-arrow"></i>
                                </button>

                                <!-- Floating Searchable Country List Dropdown -->
                                <div class="leadwa-country-dropdown" id="leadwa_country_dropdown" style="display: none;" onclick="event.stopPropagation()">
                                    <div class="leadwa-country-search-wrap">
                                        <i class="fas fa-search text-muted"></i>
                                        <input type="text" id="country_search_input" placeholder="Search country or dial code (e.g. +1, USA, BD)..." autocomplete="off" oninput="filterCountryList(this.value)">
                                    </div>
                                    <div class="leadwa-country-list" id="country_list_container">
                                        <!-- Popular Section -->
                                        <div class="leadwa-country-section-header" id="popular_header">Popular Countries</div>
                                        <?php foreach ($allCountries as $c): ?>
                                            <?php if (!empty($c['popular'])): ?>
                                                <div class="leadwa-country-item leadwa-item-popular <?= $c['code'] === $initialCountry['code'] ? 'active' : '' ?>" 
                                                     data-code="<?= htmlspecialchars($c['code']) ?>" 
                                                     data-dial="<?= htmlspecialchars($c['dial_code']) ?>" 
                                                     data-name="<?= htmlspecialchars($c['name']) ?>" 
                                                     data-flag="<?= htmlspecialchars($c['flag']) ?>" 
                                                     onclick="selectCountry('<?= htmlspecialchars($c['code']) ?>', '<?= htmlspecialchars($c['dial_code']) ?>', '<?= htmlspecialchars(addslashes($c['name'])) ?>', '<?= htmlspecialchars($c['flag']) ?>')">
                                                    <div class="leadwa-country-item-left">
                                                        <span class="leadwa-flag-icon">
                                                            <img src="https://flagcdn.com/20x15/<?= strtolower($c['code']) ?>.png" 
                                                                 srcset="https://flagcdn.com/40x30/<?= strtolower($c['code']) ?>.png 2x" 
                                                                 width="20" height="15" 
                                                                 alt="<?= htmlspecialchars($c['code']) ?>" 
                                                                 loading="lazy" 
                                                                 onerror="this.style.display='none';this.nextElementSibling.style.display='inline-block';">
                                                            <span class="leadwa-flag-emoji" style="display:none;"><?= $c['flag'] ?></span>
                                                        </span>
                                                        <span class="leadwa-country-item-name"><?= htmlspecialchars($c['name']) ?></span>
                                                    </div>
                                                    <span class="leadwa-country-item-code">+<?= htmlspecialchars($c['dial_code']) ?></span>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>

                                        <!-- All Countries Section -->
                                        <div class="leadwa-country-section-header" id="all_header">All Countries</div>
                                        <?php foreach ($allCountries as $c): ?>
                                            <div class="leadwa-country-item leadwa-item-all <?= $c['code'] === $initialCountry['code'] ? 'active' : '' ?>" 
                                                 data-code="<?= htmlspecialchars($c['code']) ?>" 
                                                 data-dial="<?= htmlspecialchars($c['dial_code']) ?>" 
                                                 data-name="<?= htmlspecialchars($c['name']) ?>" 
                                                 data-flag="<?= htmlspecialchars($c['flag']) ?>" 
                                                 onclick="selectCountry('<?= htmlspecialchars($c['code']) ?>', '<?= htmlspecialchars($c['dial_code']) ?>', '<?= htmlspecialchars(addslashes($c['name'])) ?>', '<?= htmlspecialchars($c['flag']) ?>')">
                                                <div class="leadwa-country-item-left">
                                                    <span class="leadwa-flag-icon">
                                                        <img src="https://flagcdn.com/20x15/<?= strtolower($c['code']) ?>.png" 
                                                             srcset="https://flagcdn.com/40x30/<?= strtolower($c['code']) ?>.png 2x" 
                                                             width="20" height="15" 
                                                             alt="<?= htmlspecialchars($c['code']) ?>" 
                                                             loading="lazy" 
                                                             onerror="this.style.display='none';this.nextElementSibling.style.display='inline-block';">
                                                        <span class="leadwa-flag-emoji" style="display:none;"><?= $c['flag'] ?></span>
                                                    </span>
                                                    <span class="leadwa-country-item-name"><?= htmlspecialchars($c['name']) ?></span>
                                                </div>
                                                <span class="leadwa-country-item-code">+<?= htmlspecialchars($c['dial_code']) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Hidden Fields for Country ISO & Dial Code -->
                            <input type="hidden" name="selected_country_iso" id="selected_country_iso" value="<?= htmlspecialchars($initialCountry['code']) ?>">
                            <input type="hidden" name="selected_country_dial" id="selected_country_dial" value="<?= htmlspecialchars($initialCountry['dial_code']) ?>">

                            <!-- Phone Input -->
                            <input type="text" 
                                   id="recipient_phone" 
                                   name="recipient_phone" 
                                   class="leadwa-phone-input" 
                                   placeholder="Enter phone number (e.g. 01712345678 or +<?= htmlspecialchars($initialCountry['dial_code']) ?>...)" 
                                   value="<?= htmlspecialchars((string)$prefillPhone) ?>" 
                                   autocomplete="off"
                                   required>

                            <!-- Clear Button -->
                            <button type="button" class="leadwa-phone-btn leadwa-btn-clear" onclick="clearPhoneInput()" title="Clear number input">
                                <i class="fas fa-times"></i>
                            </button>

                            <!-- Verify Button -->
                            <button type="button" id="btn_verify_phone" class="leadwa-phone-btn leadwa-btn-verify" onclick="verifyPhoneNumber()" title="Verify number on WhatsApp before dispatch">
                                <i class="fab fa-whatsapp text-success"></i> <span class="leadwa-verify-text">Verify on WhatsApp</span>
                            </button>
                        </div>

                        <!-- Live E.164 Normalization Preview -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 6px; font-size: 12px; color: #64748b; flex-wrap: wrap; gap: 4px;">
                            <div id="live_preview_wrapper" style="display: flex; align-items: center; gap: 6px;">
                                <span>Will dispatch to: <code id="live_normalized_preview" style="color: #059669; font-weight: 600;">+<?= htmlspecialchars($initialCountry['dial_code']) ?>...</code></span>
                                <span id="live_validation_pill" class="badge" style="background: #10b981; font-size: 10px; display: none;">Valid E.164</span>
                            </div>
                            <div id="phone_format_tip" class="text-muted" style="font-size: 11px;">
                                Selected dial code: <code id="tip_dial_code">+<?= htmlspecialchars($initialCountry['dial_code']) ?></code> (<span id="tip_country_name"><?= htmlspecialchars($initialCountry['name']) ?></span>)
                            </div>
                        </div>

                        <!-- Quick Country Selector Chips -->
                        <div class="leadwa-country-chips">
                            <span style="font-size: 11px; color: #64748b; margin-right: 4px; font-weight: 600;">Quick pick:</span>
                            <?php 
                            $quickChips = [
                                ['code' => 'BD', 'dial' => '880', 'flag' => '🇧🇩', 'name' => 'Bangladesh', 'label' => 'BD +880'],
                                ['code' => 'US', 'dial' => '1', 'flag' => '🇺🇸', 'name' => 'United States', 'label' => 'US/CA +1'],
                                ['code' => 'GB', 'dial' => '44', 'flag' => '🇬🇧', 'name' => 'United Kingdom', 'label' => 'UK +44'],
                                ['code' => 'AE', 'dial' => '971', 'flag' => '🇦🇪', 'name' => 'United Arab Emirates', 'label' => 'UAE +971'],
                                ['code' => 'SA', 'dial' => '966', 'flag' => '🇸🇦', 'name' => 'Saudi Arabia', 'label' => 'KSA +966'],
                                ['code' => 'IN', 'dial' => '91', 'flag' => '🇮🇳', 'name' => 'India', 'label' => 'IN +91'],
                                ['code' => 'PK', 'dial' => '92', 'flag' => '🇵🇰', 'name' => 'Pakistan', 'label' => 'PK +92'],
                                ['code' => 'AU', 'dial' => '61', 'flag' => '🇦🇺', 'name' => 'Australia', 'label' => 'AU +61'],
                                ['code' => 'DE', 'dial' => '49', 'flag' => '🇩🇪', 'name' => 'Germany', 'label' => 'DE +49'],
                                ['code' => 'SG', 'dial' => '65', 'flag' => '🇸🇬', 'name' => 'Singapore', 'label' => 'SG +65'],
                                ['code' => 'MY', 'dial' => '60', 'flag' => '🇲🇾', 'name' => 'Malaysia', 'label' => 'MY +60'],
                                ['code' => 'QA', 'dial' => '974', 'flag' => '🇶🇦', 'name' => 'Qatar', 'label' => 'QA +974'],
                            ];
                            foreach ($quickChips as $qc): ?>
                                <span class="leadwa-country-chip" onclick="selectCountry('<?= $qc['code'] ?>', '<?= $qc['dial'] ?>', '<?= htmlspecialchars(addslashes($qc['name'])) ?>', '<?= $qc['flag'] ?>')">
                                    <span class="leadwa-chip-flag">
                                        <img src="https://flagcdn.com/16x12/<?= strtolower($qc['code']) ?>.png" 
                                             srcset="https://flagcdn.com/32x24/<?= strtolower($qc['code']) ?>.png 2x" 
                                             width="16" height="12" 
                                             alt="<?= $qc['code'] ?>" 
                                             loading="lazy" 
                                             onerror="this.style.display='none';this.nextElementSibling.style.display='inline';">
                                        <span class="leadwa-flag-emoji" style="display:none;"><?= $qc['flag'] ?></span>
                                    </span>
                                    +<?= $qc['dial'] ?> (<?= $qc['code'] ?>)
                                </span>
                            <?php endforeach; ?>
                        </div>

                        <!-- Dynamic Validation / API Status Notice -->
                        <div id="phone_validation_status" style="margin-top: 8px; font-size: 12px; display: none;"></div>
                    </div>

                    <!-- Message Body -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label for="message_text" style="font-weight: 600; color: #334155; font-size: 13px; margin: 0;">
                                Message Body <span class="text-danger">*</span>
                            </label>
                            <span id="char_counter" style="font-size: 12px; color: #64748b; font-weight: 600;">0 characters</span>
                        </div>

                        <!-- Quick Sample Presets -->
                        <div class="leadwa-preset-chips">
                            <span style="font-size: 11px; color: #64748b; align-self: center; margin-right: 2px;">Sample presets:</span>
                            <span class="leadwa-preset-chip" onclick="setSamplePreset('ping')">
                                <i class="fas fa-paper-plane text-primary"></i> Test Ping
                            </span>
                            <span class="leadwa-preset-chip" onclick="setSamplePreset('invoice')">
                                <i class="fas fa-file-invoice text-success"></i> Invoice Notice
                            </span>
                            <span class="leadwa-preset-chip" onclick="setSamplePreset('ticket')">
                                <i class="fas fa-headset text-warning"></i> Support Ticket
                            </span>
                            <span class="leadwa-preset-chip" onclick="setSamplePreset('otp')">
                                <i class="fas fa-shield-alt text-danger"></i> 2FA OTP Code
                            </span>
                        </div>

                        <textarea id="message_text" 
                                  name="message_text" 
                                  class="form-control" 
                                  rows="5" 
                                  placeholder="Type your WhatsApp message here..." 
                                  oninput="updateCharCount()" 
                                  required 
                                  style="resize: vertical; font-size: 14px; line-height: 1.5; border-radius: 8px; border-color: #cbd5e1;"><?= $prefillClientId > 0 ? "Hello,\nThis is an important account notification regarding your service." : "Test message from WHMCS via LeadWhatsApp API! 🚀" ?></textarea>
                        
                        <div style="display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; margin-top: 6px;">
                            <span>Formatting tips: <code>*bold*</code>, <code>_italic_</code>, <code>~strikethrough~</code>, <code>`monospace`</code></span>
                            <span>Direct API Dispatch &bull; LeadWhatsApp Gateway</span>
                        </div>
                    </div>

                    <!-- Optional Document / PDF Invoice Attachment -->
                    <div style="margin-bottom: 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 16px;">
                        <label style="font-weight: 600; color: #334155; font-size: 13px; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
                            <span><i class="fas fa-paperclip text-primary"></i> Attach Invoice or Media (Optional)</span>
                            <span class="text-muted" style="font-weight: normal; font-size: 11px;">PDF, Images, Documents</span>
                        </label>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label for="attach_invoice_id" style="font-size: 11px; color: #64748b; font-weight: 600;">WHMCS Invoice #</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fas fa-file-invoice" style="color: #ef4444;"></i></span>
                                        <input type="number" id="attach_invoice_id" name="attach_invoice_id" class="form-control input-sm" placeholder="e.g. 1042">
                                    </div>
                                    <span class="help-block" style="font-size: 10px; margin-bottom: 0;">Auto-generates WHMCS PDF invoice</span>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label for="attachment_url" style="font-size: 11px; color: #64748b; font-weight: 600;">Or Direct File / Document URL</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fas fa-link"></i></span>
                                        <input type="url" id="attachment_url" name="attachment_url" class="form-control input-sm" placeholder="https://example.com/document.pdf">
                                    </div>
                                    <span class="help-block" style="font-size: 10px; margin-bottom: 0;">Publicly accessible URL to PDF, Image or Document</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #f1f5f9; display: flex; justify-content: flex-end; gap: 12px; align-items: center;">
                        <a href="<?= $moduleLink ?>" class="btn btn-default" style="font-weight: 500;">Cancel</a>
                        <button type="submit" id="btn_submit_send" class="btn btn-success" style="background: #10b981; border-color: #059669; font-weight: 600; padding: 10px 28px; border-radius: 8px; box-shadow: 0 2px 6px rgba(16, 185, 129, 0.3);">
                            <i class="fab fa-whatsapp"></i> Send WhatsApp Message
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
var COUNTRIES_DATA = <?= json_encode($allCountries) ?>;
var activeCountry = {
    code: '<?= $initialCountry['code'] ?>',
    dial: '<?= $initialCountry['dial_code'] ?>',
    name: '<?= addslashes($initialCountry['name']) ?>',
    flag: '<?= $initialCountry['flag'] ?>'
};

// Toggle country dropdown visibility
function toggleCountryDropdown(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    var dropdown = document.getElementById('leadwa_country_dropdown');
    var btn = document.getElementById('leadwa_country_btn');
    if (!dropdown || !btn) return;

    var isOpen = dropdown.style.display === 'flex';
    if (isOpen) {
        closeCountryDropdown();
    } else {
        dropdown.style.display = 'flex';
        btn.classList.add('open');
        var searchInput = document.getElementById('country_search_input');
        if (searchInput) {
            searchInput.value = '';
            filterCountryList('');
            setTimeout(function() { searchInput.focus(); }, 50);
        }
    }
}

function closeCountryDropdown() {
    var dropdown = document.getElementById('leadwa_country_dropdown');
    var btn = document.getElementById('leadwa_country_btn');
    if (dropdown) dropdown.style.display = 'none';
    if (btn) btn.classList.remove('open');
}

// Filter country list by search query (name, ISO code, or dial code)
function filterCountryList(query) {
    query = (query || '').toLowerCase().trim().replace(/^\+/, '');
    var items = document.querySelectorAll('.leadwa-country-item');
    var popularHeader = document.getElementById('popular_header');
    var allHeader = document.getElementById('all_header');
    var visiblePopularCount = 0;
    var visibleAllCount = 0;

    items.forEach(function(item) {
        var name = (item.getAttribute('data-name') || '').toLowerCase();
        var code = (item.getAttribute('data-code') || '').toLowerCase();
        var dial = (item.getAttribute('data-dial') || '').toLowerCase();
        var isPopular = item.classList.contains('leadwa-item-popular');

        var match = !query || name.indexOf(query) !== -1 || code.indexOf(query) !== -1 || dial.indexOf(query) !== -1;
        item.style.display = match ? 'flex' : 'none';

        if (match) {
            if (isPopular) visiblePopularCount++;
            else visibleAllCount++;
        }
    });

    if (popularHeader) popularHeader.style.display = (visiblePopularCount > 0 && !query) ? 'block' : 'none';
    if (allHeader) allHeader.style.display = (visibleAllCount > 0 && !query) ? 'block' : 'none';
}

// Select a country and update UI
function selectCountry(code, dial, name, flag, triggerInputFocus) {
    activeCountry = {
        code: code,
        dial: dial.replace(/\D/g, ''),
        name: name,
        flag: flag
    };

    // Update trigger button flag image and emoji fallback
    var flagContainer = document.getElementById('selected_country_flag');
    if (flagContainer) {
        flagContainer.innerHTML = '<img src="https://flagcdn.com/20x15/' + code.toLowerCase() + '.png" srcset="https://flagcdn.com/40x30/' + code.toLowerCase() + '.png 2x" width="20" height="15" alt="' + code + '" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'inline-block\';"><span class="leadwa-flag-emoji" style="display:none;">' + flag + '</span>';
    }

    // Update dial code badge in trigger
    var dialPrefix = document.getElementById('selected_dial_prefix');
    if (dialPrefix) {
        dialPrefix.textContent = '+' + activeCountry.dial;
    }

    // Update tips and hidden fields
    var tipDial = document.getElementById('tip_dial_code');
    var tipName = document.getElementById('tip_country_name');
    var hiddenIso = document.getElementById('selected_country_iso');
    var hiddenDial = document.getElementById('selected_country_dial');

    if (tipDial) tipDial.textContent = '+' + activeCountry.dial;
    if (tipName) tipName.textContent = activeCountry.name;
    if (hiddenIso) hiddenIso.value = activeCountry.code;
    if (hiddenDial) hiddenDial.value = activeCountry.dial;

    // Update active highlight in dropdown
    var items = document.querySelectorAll('.leadwa-country-item');
    items.forEach(function(item) {
        if (item.getAttribute('data-code') === code) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    closeCountryDropdown();

    var phoneInput = document.getElementById('recipient_phone');
    if (phoneInput && triggerInputFocus !== false) {
        phoneInput.focus();
    }
    updateLivePreview();
}

// Select country by ISO-2 code (e.g. 'US', 'GB', 'BD', 'AE')
function selectCountryByIso(isoCode) {
    if (!isoCode) return;
    isoCode = isoCode.toUpperCase().trim();
    for (var i = 0; i < COUNTRIES_DATA.length; i++) {
        if (COUNTRIES_DATA[i].code === isoCode) {
            var c = COUNTRIES_DATA[i];
            selectCountry(c.code, c.dial_code, c.name, c.flag, false);
            return;
        }
    }
}

// Detect country from typed or pasted international phone number
function detectCountryFromPhone(phone) {
    if (!phone) return null;
    var trimmed = phone.trim();
    var digits = trimmed.replace(/[^\d+]/g, '');
    if (!digits) return null;

    if (digits.indexOf('00') === 0) digits = '+' + digits.substring(2);
    if (digits.indexOf('+') === 0) digits = digits.substring(1);

    // WHMCS dot notation: e.g. "880.017..."
    if (trimmed.indexOf('.') !== -1) {
        var ccPart = trimmed.split('.')[0].replace(/\D/g, '');
        if (ccPart) digits = ccPart;
    }

    // Match longest dial code first
    var sorted = COUNTRIES_DATA.slice().sort(function(a, b) {
        return b.dial_code.length - a.dial_code.length;
    });

    for (var i = 0; i < sorted.length; i++) {
        var d = sorted[i].dial_code;
        if (digits.indexOf(d) === 0) {
            return sorted[i];
        }
    }
    return null;
}

// Normalize phone client-side for live preview & submission
function clientNormalizePhone(raw, defDial) {
    if (!raw) return '';
    defDial = (defDial || activeCountry.dial || '880').replace(/\D/g, '') || '880';
    var trimmed = raw.trim();

    // WHMCS dotted format e.g. 880.017... or 880.17...
    if (trimmed.indexOf('.') !== -1) {
        var parts = trimmed.split('.');
        var cc = parts[0].replace(/\D/g, '');
        var num = parts[1].replace(/\D/g, '').replace(/^0+/, '');
        if (cc && num) return '+' + cc + num;
    }

    var clean = trimmed.replace(/[^\d+]/g, '');
    if (!clean) return '';

    if (clean.indexOf('00') === 0) {
        clean = '+' + clean.substring(2);
    }

    if (clean.indexOf('+') === 0) {
        var numDigits = clean.substring(1);
        if (numDigits.indexOf(defDial + '0') === 0) {
            numDigits = defDial + numDigits.substring(defDial.length + 1);
        }
        return '+' + numDigits.replace(/^0+/, '');
    }

    if (clean.indexOf('0') === 0 && defDial) {
        return '+' + defDial + clean.replace(/^0+/, '');
    }

    if (clean.indexOf(defDial + '0') === 0) {
        return '+' + defDial + clean.substring(defDial.length + 1);
    }

    if (clean.indexOf(defDial) === 0) {
        return '+' + clean;
    }

    if (clean.length <= 10 && defDial) {
        return '+' + defDial + clean.replace(/^0+/, '');
    }

    return '+' + clean;
}

function updateLivePreview() {
    var phoneInput = document.getElementById('recipient_phone');
    var previewSpan = document.getElementById('live_normalized_preview');
    var validationPill = document.getElementById('live_validation_pill');
    if (!phoneInput || !previewSpan) return;

    var raw = phoneInput.value;
    if (!raw || !raw.trim()) {
        previewSpan.textContent = '+' + activeCountry.dial + '...';
        previewSpan.style.color = '#94a3b8';
        if (validationPill) validationPill.style.display = 'none';
        return;
    }

    var normalized = clientNormalizePhone(raw, activeCountry.dial);
    previewSpan.textContent = normalized;
    previewSpan.style.color = '#059669';

    // Check E.164 validity (+ followed by 7 to 15 digits)
    var isValidE164 = /^\+[1-9]\d{6,14}$/.test(normalized);
    if (validationPill) {
        if (isValidE164) {
            validationPill.style.display = 'inline-block';
            validationPill.style.background = '#059669';
            validationPill.textContent = 'E.164 Ready';
        } else {
            validationPill.style.display = 'inline-block';
            validationPill.style.background = '#d97706';
            validationPill.textContent = 'Incomplete';
        }
    }
}

// On typing or pasting, auto-sync country if international code is entered
function onPhoneInputChanged() {
    var phoneInput = document.getElementById('recipient_phone');
    if (!phoneInput) return;

    var val = phoneInput.value.trim();
    if (val.indexOf('+') === 0 || (val.indexOf('00') === 0 && val.length >= 4)) {
        var detected = detectCountryFromPhone(val);
        if (detected && detected.code !== activeCountry.code) {
            selectCountry(detected.code, detected.dial_code, detected.name, detected.flag, false);
        }
    }
    updateLivePreview();
}

function setSenderMode(mode) {
    var tabManual = document.getElementById('tab_mode_manual');
    var tabClient = document.getElementById('tab_mode_client');
    var clientWrapper = document.getElementById('client_select_wrapper');
    var indicator = document.getElementById('phone_mode_indicator');

    if (mode === 'client') {
        if (tabClient) tabClient.classList.add('active');
        if (tabManual) tabManual.classList.remove('active');
        if (clientWrapper) clientWrapper.style.display = 'block';
        if (indicator) indicator.innerHTML = '<span class="text-primary"><i class="fas fa-users"></i> WHMCS Client Mode</span>';
    } else {
        if (tabManual) tabManual.classList.add('active');
        if (tabClient) tabClient.classList.remove('active');
        if (clientWrapper) clientWrapper.style.display = 'none';
        if (indicator) indicator.innerHTML = '<span class="text-muted"><i class="fas fa-keyboard"></i> Manual Mode</span>';
    }
}

function applySelectedPhone(clientId, phone, name, email, country) {
    var phoneInput = document.getElementById('recipient_phone');
    var hiddenClientId = document.getElementById('hidden_client_id');
    var card = document.getElementById('selected_client_card');
    var cardName = document.getElementById('card_client_name');
    var cardId = document.getElementById('card_client_id');
    var cardEmail = document.getElementById('card_client_email');
    var cardPhone = document.getElementById('card_client_phone');
    var statusDiv = document.getElementById('phone_validation_status');

    if (hiddenClientId) {
        hiddenClientId.value = clientId || '';
    }

    // Auto-select client country if provided
    if (country) {
        selectCountryByIso(country);
    } else if (phone) {
        var detected = detectCountryFromPhone(phone);
        if (detected) {
            selectCountry(detected.code, detected.dial_code, detected.name, detected.flag, false);
        }
    }

    if (phoneInput && phone) {
        phoneInput.value = phone;
        updateLivePreview();
    }

    if (clientId && name) {
        if (card) card.style.display = 'flex';
        if (cardName) cardName.textContent = name;
        if (cardId) cardId.textContent = '#' + clientId;
        if (cardEmail) cardEmail.textContent = email || 'No email';
        if (cardPhone) cardPhone.textContent = phone || 'No phone registered';

        if (statusDiv) {
            if (!phone) {
                statusDiv.style.display = 'block';
                statusDiv.innerHTML = '<div class="alert alert-warning" style="margin: 0; padding: 8px 12px;"><i class="fas fa-exclamation-triangle"></i> This client has no phone number on profile. Please enter number manually.</div>';
            } else {
                statusDiv.style.display = 'none';
                statusDiv.innerHTML = '';
            }
        }
    } else {
        if (card) card.style.display = 'none';
    }
}

function clearSelectedClient() {
    var select = document.getElementById('client_select');
    if (select) {
        select.value = '';
        if (window.jQuery && window.jQuery(select).data('select2')) {
            window.jQuery(select).val('').trigger('change');
        }
    }
    applySelectedPhone('', '', '', '', '');
    setSenderMode('manual');
}

function clearPhoneInput() {
    var phoneInput = document.getElementById('recipient_phone');
    var statusDiv = document.getElementById('phone_validation_status');
    if (phoneInput) {
        phoneInput.value = '';
        phoneInput.focus();
    }
    if (statusDiv) {
        statusDiv.style.display = 'none';
        statusDiv.innerHTML = '';
    }
    updateLivePreview();
}

function setSamplePreset(type) {
    var textarea = document.getElementById('message_text');
    if (!textarea) return;

    var tpls = {
        ping: "Test message from WHMCS via LeadWhatsApp API! 🚀 Connected successfully.",
        invoice: "Hello,\nThis is a friendly reminder that Invoice #1042 for $49.00 is due. Please visit your client portal to make payment.\n\nThank you for choosing our services!",
        ticket: "Hello,\nYour support ticket #TKT-8921 has been updated by our support team. Please log in to your account to review the response.",
        otp: "Your WHMCS verification security code is: *481923*.\nThis code is valid for 5 minutes. Do not share it with anyone."
    };

    textarea.value = tpls[type] || tpls.ping;
    updateCharCount();
    textarea.focus();
}

function updateCharCount() {
    var textarea = document.getElementById('message_text');
    var counter = document.getElementById('char_counter');
    if (textarea && counter) {
        counter.textContent = textarea.value.length + ' characters';
    }
}

function verifyPhoneNumber() {
    var phoneInput = document.getElementById('recipient_phone');
    var statusDiv = document.getElementById('phone_validation_status');
    var verifyBtn = document.getElementById('btn_verify_phone');
    if (!phoneInput) return;

    var rawPhone = phoneInput.value.trim();
    if (!rawPhone) {
        if (statusDiv) {
            statusDiv.style.display = 'block';
            statusDiv.innerHTML = '<div class="alert alert-danger" style="margin:0; padding: 8px 12px;"><i class="fas fa-times-circle"></i> Please enter a phone number to verify.</div>';
        }
        return;
    }

    var normalizedPhone = clientNormalizePhone(rawPhone, activeCountry.dial);

    if (verifyBtn) {
        verifyBtn.disabled = true;
        verifyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
    }
    if (statusDiv) {
        statusDiv.style.display = 'block';
        statusDiv.innerHTML = '<div class="alert alert-info" style="margin:0; padding: 8px 12px;"><i class="fas fa-spinner fa-spin"></i> Checking WhatsApp account status for <code>' + normalizedPhone + '</code>...</div>';
    }

    var formData = new FormData();
    formData.append('action', 'validate_phone');
    formData.append('phone', normalizedPhone);
    formData.append('ajax', '1');

    fetch('<?= $moduleLink ?>', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (verifyBtn) {
            verifyBtn.disabled = false;
            verifyBtn.innerHTML = '<i class="fab fa-whatsapp text-success"></i> <span class="leadwa-verify-text">Verify on WhatsApp</span>';
        }
        if (statusDiv) {
            if (data.success) {
                var checkedPhone = (data.data && data.data.phone) ? data.data.phone : normalizedPhone;
                phoneInput.value = checkedPhone;
                updateLivePreview();
                statusDiv.innerHTML = '<div class="alert alert-success" style="margin:0; padding: 8px 12px; font-weight: 600;"><i class="fas fa-check-circle"></i> Active WhatsApp Account: <code>' + checkedPhone + '</code></div>';
            } else {
                statusDiv.innerHTML = '<div class="alert alert-danger" style="margin:0; padding: 8px 12px; font-weight: 600;"><i class="fas fa-exclamation-triangle"></i> ' + (data.message || 'Number is not registered on WhatsApp.') + '</div>';
            }
        }
    })
    .catch(function(err) {
        if (verifyBtn) {
            verifyBtn.disabled = false;
            verifyBtn.innerHTML = '<i class="fab fa-whatsapp text-success"></i> <span class="leadwa-verify-text">Verify on WhatsApp</span>';
        }
        if (statusDiv) {
            statusDiv.innerHTML = '<div class="alert alert-warning" style="margin:0; padding: 8px 12px;"><i class="fas fa-info-circle"></i> Verification response received.</div>';
        }
    });
}

function handleFormSubmit(form) {
    var phoneInput = document.getElementById('recipient_phone');
    if (phoneInput && phoneInput.value.trim()) {
        // Normalize number with selected country dial code before submission
        phoneInput.value = clientNormalizePhone(phoneInput.value.trim(), activeCountry.dial);
    }

    var btn = document.getElementById('btn_submit_send');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Dispatching Message...';
    }
    return true;
}

// Global click outside listener to close country dropdown
document.addEventListener('click', function(e) {
    var dropdown = document.getElementById('leadwa_country_dropdown');
    var btn = document.getElementById('leadwa_country_btn');
    if (dropdown && dropdown.style.display === 'flex') {
        if (!dropdown.contains(e.target) && !btn.contains(e.target)) {
            closeCountryDropdown();
        }
    }
});

// Escape key listener to close country dropdown
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
        closeCountryDropdown();
    }
});

// Initialization on DOM & Select2
document.addEventListener('DOMContentLoaded', function() {
    updateCharCount();
    updateLivePreview();

    var phoneInput = document.getElementById('recipient_phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', onPhoneInputChanged);
        phoneInput.addEventListener('change', onPhoneInputChanged);
        phoneInput.addEventListener('paste', function() {
            setTimeout(onPhoneInputChanged, 20);
        });
    }

    // Bind Select2 and Native Select changes
    function onSelectChange(target) {
        var opt = target.options[target.selectedIndex];
        if (!opt) return;
        var clientId = target.value;
        var phone = opt.getAttribute('data-phone') || '';
        var name = opt.getAttribute('data-name') || '';
        var email = opt.getAttribute('data-email') || '';
        var country = opt.getAttribute('data-country') || '';
        applySelectedPhone(clientId, phone, name, email, country);
    }

    var clientSelectEl = document.getElementById('client_select');
    if (clientSelectEl) {
        clientSelectEl.addEventListener('change', function() {
            onSelectChange(this);
        });
    }

    // jQuery & Select2 support for WHMCS Admin panel
    if (window.jQuery) {
        window.jQuery('#client_select').on('change select2:select', function() {
            var $this = window.jQuery(this);
            var opt = $this.find('option:selected');
            var clientId = $this.val();
            var phone = opt.data('phone') || opt.attr('data-phone') || '';
            var name = opt.data('name') || opt.attr('data-name') || '';
            var email = opt.data('email') || opt.attr('data-email') || '';
            var country = opt.data('country') || opt.attr('data-country') || '';
            applySelectedPhone(clientId, phone, name, email, country);
        });
    }

    // Trigger initial select if prefilled
    if (clientSelectEl && clientSelectEl.value) {
        onSelectChange(clientSelectEl);
    }
});
</script>
