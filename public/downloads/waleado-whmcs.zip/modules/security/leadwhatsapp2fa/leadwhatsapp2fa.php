<?php
/**
 * LeadWhatsApp Two-Factor Authentication Security Module for WHMCS
 *
 * @package    WHMCS
 * @author     LeadWhatsApp
 * @copyright  Copyright (c) LeadWhatsApp 2026
 * @link       https://leadwhats.app
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

// Require module core classes
$addonBase = dirname(__DIR__, 2) . '/addons/leadwhatsapp';
if (file_exists($addonBase . '/vendor/autoload.php')) {
    require_once $addonBase . '/vendor/autoload.php';
} else {
    spl_autoload_register(function ($class) {
        $prefix = 'LeadWhatsApp\\';
        $baseDir = dirname(__DIR__, 2) . '/addons/leadwhatsapp/src/';
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    });
}

use LeadWhatsApp\Database;
use LeadWhatsApp\PhoneHelper;
use LeadWhatsApp\TemplateService;
use WHMCS\Database\Capsule;

/**
 * 2FA Module Configuration
 */
function leadwhatsapp2fa_config(): array
{
    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => 'WhatsApp Verification (LeadWhatsApp)',
        ],
        'Description' => [
            'Type' => 'System',
            'Value' => 'Sends a 6-digit one-time verification code (OTP) via WhatsApp to verify client and administrator logins.',
        ],
    ];
}

/**
 * 2FA Activation Handler
 */
function leadwhatsapp2fa_activate(array $params): array
{
    $userId = (int)($params['user_id'] ?? $params['client_id'] ?? $params['admin_id'] ?? 0);
    $userType = !empty($params['admin_id']) ? 'admin' : 'client';

    // Verify phone number exists
    $phone = null;
    if ($userType === 'client' && $userId > 0) {
        $phone = PhoneHelper::getClientPhone($userId);
    } elseif ($userType === 'admin') {
        $config = Database::getModuleConfig();
        $phone = $config['admin_phone'] ?? '';
    }

    if (empty($phone)) {
        return [
            'response' => 'error',
            'msg' => 'No valid WhatsApp phone number found on your profile. Please add your mobile number with country code first.',
        ];
    }

    return [
        'response' => 'success',
        'msg' => 'LeadWhatsApp Two-Factor Authentication has been successfully enabled on your account.',
    ];
}

/**
 * 2FA Challenge Handler - Dispatches OTP and renders challenge input
 */
function leadwhatsapp2fa_challenge(array $params): string
{
    $userId = (int)($params['user_id'] ?? $params['client_id'] ?? $params['admin_id'] ?? 0);
    $userType = !empty($params['admin_id']) ? 'admin' : 'client';

    $phone = '';
    if ($userType === 'client' && $userId > 0) {
        $phone = PhoneHelper::getClientPhone($userId) ?? '';
    } elseif ($userType === 'admin') {
        $config = Database::getModuleConfig();
        $phone = $config['admin_phone'] ?? '';
    }

    if (empty($phone)) {
        return '<div class="alert alert-danger">Cannot send verification code: No phone number associated with this account.</div>';
    }

    // Generate 6-digit cryptographic OTP code
    try {
        $otp = (string)random_int(100000, 999999);
    } catch (\Throwable $e) {
        $otp = (string)mt_rand(100000, 999999);
    }

    // Store in DB with 5 minute expiration
    Database::createOtpSession($userId, $userType, $phone, $otp, 5);

    // Mask phone number for display (e.g. +88017****5678)
    $phoneLen = strlen($phone);
    $maskedPhone = $phoneLen > 6 ? substr($phone, 0, 6) . '****' . substr($phone, -3) : $phone;

    // Send OTP via LeadWhatsApp API
    TemplateService::dispatch('two_factor_otp', [
        'otp_code' => $otp,
        'expires_minutes' => 5,
    ], $phone, $userId, '2fa', $userId);

    // Return HTML challenge form
    $html = '
    <div style="text-align: center; margin: 15px 0;">
        <div style="font-size: 32px; color: #25D366; margin-bottom: 10px;">
            <i class="fab fa-whatsapp"></i>
        </div>
        <p style="font-size: 14px; color: #334155;">
            A 6-digit verification code was sent to your WhatsApp number: <strong>' . htmlspecialchars($maskedPhone) . '</strong>
        </p>
        <div class="form-group" style="max-width: 240px; margin: 16px auto;">
            <input type="text" name="otpcode" class="form-control text-center input-lg" placeholder="000000" maxlength="6" autofocus autocomplete="one-time-code" style="letter-spacing: 8px; font-size: 24px; font-weight: bold; height: 48px; border-radius: 8px; border: 2px solid #cbd5e1;" required />
        </div>
        <p style="font-size: 12px; color: #64748b;">
            Code expires in 5 minutes. Did not receive it? Refresh the page to resend.
        </p>
    </div>';

    return $html;
}

/**
 * 2FA Verify Handler - Validates user submitted OTP
 */
function leadwhatsapp2fa_verify(array $params): bool
{
    $userId = (int)($params['user_id'] ?? $params['client_id'] ?? $params['admin_id'] ?? 0);
    $userType = !empty($params['admin_id']) ? 'admin' : 'client';
    $submittedCode = trim($_POST['otpcode'] ?? $_POST['twofactorcode'] ?? '');

    if (empty($submittedCode) || strlen($submittedCode) < 4) {
        return false;
    }

    return Database::verifyOtp($userId, $userType, $submittedCode);
}
